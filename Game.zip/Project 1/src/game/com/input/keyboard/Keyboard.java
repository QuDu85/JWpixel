package game.com.input.keyboard;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyboard implements KeyListener{
	private boolean [] keys = new boolean[65536];
	public boolean up;
	public boolean down;
	public boolean left;
	public boolean right;
	public boolean run;
	public boolean attack;
	public boolean pause;
	public boolean changemode;
	
	public void update() {
		up = keys[KeyEvent.VK_W] || keys[KeyEvent.VK_UP];
		down = keys[KeyEvent.VK_S] || keys[KeyEvent.VK_DOWN]; 
		left = keys[KeyEvent.VK_A] || keys[KeyEvent.VK_LEFT];
		right = keys[KeyEvent.VK_D] || keys[KeyEvent.VK_RIGHT];
		attack = keys[KeyEvent.VK_J];
		run = keys[KeyEvent.VK_SHIFT];
		pause=keys[KeyEvent.VK_ESCAPE];
		changemode=keys[KeyEvent.VK_K];
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
//		System.out.println(KeyEvent.getKeyText(e.getKeyCode()));
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}
	

}
