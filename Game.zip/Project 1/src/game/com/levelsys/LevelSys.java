package game.com.levelsys;

import java.util.ArrayList;
import java.util.List;

import game.com.Game;
import game.com.UI.UIManager;
import game.com.input.keyboard.Keyboard;
import game.com.input.mouse.Mouse;
import game.com.level.Level;
import game.com.level.entity.Entity;
import game.com.level.entity.mob.Mob.STATE;
import game.com.level.entity.mob.player.Player;
import game.com.level.gate.Gate;

public class LevelSys {
	List<Level> levels=new ArrayList<>();
	List<Gate> gates=new ArrayList<>();
	private Level curLevel;
	private Player player;
	private UIManager ui;
	private boolean gameover = false;
	
	public boolean isGameover() {
		return gameover;
	}

	public void setGameover(boolean gameover) {
		this.gameover = gameover;
	}

	public enum MODE{
		EASY, HARD
	}

	private MODE mode = MODE.EASY;
			
	public LevelSys(Mouse mouse, Keyboard key, MODE mode) {
		this.mode=mode;
		loadLevel();
		player= new Player(12,30,key,mouse);
		this.curLevel.add(player);
		player.setLevel(curLevel);
		player.setSys(this);
		player.setPos(14,12);

	}
	
	public void setMode(MODE mode) {
		this.mode = mode;
	}

	public Player getPlayer() {
		return player;
	}

	public Gate findGate(int code, Gate gate) {
		for(int i=0; i<gates.size(); i++) {
			Gate g=gates.get(i);
			if(g.getID()==code && g.getSrclevel()!= gate.getSrclevel()) return g;
		}
		return null;
	}
	
	public void change(Entity e, Gate g) {
		Level in =g.getSrclevel();
		
		Gate gate_out= findGate(g.getID(),g);
		Level out = gate_out.getSrclevel();
		e.setX((gate_out.getX()<<4) + gate_out.getWidth()/2);
		e.setY((gate_out.getY()<<4) + gate_out.getHeight()/2- e.getHeight()/2);
		out.add(e);
		in.remove(e);
		curLevel=out;
	}
	
	public void restart() {
		levels.clear();
		loadLevel();
		this.curLevel.add(player);
		player.setLevel(curLevel);
		player.setSys(this);
		player.setHealth(500);
		player.setPos(14,12);		
		player.setState(STATE.STAND);
		ui.changePanel("playerUI");
		
	}
	
	private void loadLevel() {
		if(mode==MODE.HARD) {
			levels.add(new Level("res/map/map.png","res/entitysheet/completeentity.png"));			
			levels.add(new Level("res/map/map2.png","res/entitysheet/entity2.png"));
		}else {
			levels.add(new Level("res/map/map.png","res/entitysheet/easyentity.png"));			
			levels.add(new Level("res/map/map2.png","res/entitysheet/entity2.png"));
		}
		loadGate();
		curLevel=levels.get(0);
		ui=Game.getUI();
	}
	
	public void loadGate() {
		for(int i=0;i<levels.size(); i++) {
			Level l = levels.get(i);
			for(int j=0; j<l.gates().size();j++) {
				gates.add(l.gates().get(j));
			}
		}
			
	}
	
	public Level getCurLevel() {
		return curLevel;
	}
}
