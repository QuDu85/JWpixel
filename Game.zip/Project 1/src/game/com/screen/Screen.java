package game.com.screen;

import game.com.level.Particle;
import game.com.level.entity.Entity;
import game.com.level.tile.Tile;

public class Screen {
	private int width;
	private int height;
	public int pixels [];
	private int x_ofs, y_ofs;
	
	public Screen( int width, int height) {
		this.width = width;
		this.height = height;
		pixels = new int [width*height];
		
	}
	
	public void setOffset(int x, int y) {
		this.x_ofs=x;
		this.y_ofs=y;
	}
	
	public int getX_ofs() {
		return x_ofs;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public int getY_ofs() {
		return y_ofs;
	}
	
	public void clear() {
		for(int i=0; i<pixels.length; i++) {
			pixels[i]=0;
		}
	}
	
	public void renderEntity(int x, int y, Entity entity) {
		int x0 = x - x_ofs;
		int y0 = y - y_ofs;
		for(int h =0; h<entity.getSprite().getHeight(); h++)
			for(int w=0; w<entity.getSprite().getWidth(); w++) {
				if((x0 + w)<0||(x0+w)>=width ||(y0+h)<0||(y0+h)>=height) continue;
				if(entity.getSprite().pixels[w+h*entity.getSprite().getWidth()]==0xffdc31ce) continue;
				pixels[(x0+w)+(y0+h)*width]= entity.getSprite().pixels[w+h*entity.getSprite().getWidth()];
			}
	}
	
	public void renderParticle(int x, int y, Particle p) {
		int x0 = x - x_ofs;
		int y0 = y - y_ofs;
		for(int h =0; h<p.getSize(); h++)
			for(int w=0; w<p.getSize(); w++) {
				if((x0 + w)<0||(x0+w)>=width ||(y0+h)<0||(y0+h)>=height) continue;
				pixels[(x0+w)+(y0+h)*width]= p.getColor();
			}
	}
	
	public void renderTile(int x, int y, Tile tile) {
		int x0 = x - x_ofs;
		int y0 = y - y_ofs;
		for(int h =0; h<tile.size; h++)
			for(int w=0; w<tile.size; w++) {
				if((x0 + w)<0||(x0+w)>=width ||(y0+h)<0||(y0+h)>=height) continue;
				pixels[(x0+w)+(y0+h)*width]= tile.getSprite().pixels[w+h*tile.size];
			}
		
	}
	
}
