package game.com.UI;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class UIManager {
	
	private List<UIPanel> menu = new ArrayList<UIPanel>();
	private UIPanel curPanel;
	private UIPanel tempPanel;
	private boolean visible;
	public UIManager () {
		
	}
	
	public void add(UIPanel p) {
		menu.add(p);
	}
	
	public void remove(String name) {
			for(int i = 0;i < menu.size(); i++) {
				if(menu.get(i).getName().equals(name)) tempPanel=null;
			}

	}
		
	public void setTempVisible(boolean visible) {
		this.visible = visible;
	}
	
	public void update() {
		curPanel.update();
		if(tempPanel!=null)
		tempPanel.update();
	}
	public String getCurName() {
		return curPanel.getName();
	}
	
	public void render(Graphics g) {
		curPanel.render(g);
		if(tempPanel!=null) {
			if(visible)
				tempPanel.render(g);
		}
	}
	
	public void changePanel(String name) {
		for(int i = 0;i < menu.size(); i++) {
			if(menu.get(i).getName().equals(name)) curPanel = menu.get(i);
		}

	}
	
	public void setCur(UIPanel panel) {
		curPanel = panel;
	}
	
	public void setTemp(UIPanel panel) {
		tempPanel = panel;
	}
}
