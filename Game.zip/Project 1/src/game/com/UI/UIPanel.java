package game.com.UI;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import game.com.Game;

public class UIPanel {

	private String name;
	private int x, y;
	private int width, height;
	private Color backGroundColor;

	List<UIComponent> components = new ArrayList<>();

	public UIPanel(String name, int x, int y, int width, int height, Color color) {
		this.x = x * Game.scale;
		this.y = y * Game.scale;
		this.width = width * Game.scale;
		this.height = height * Game.scale;
		this.name = name;
		this.backGroundColor = color;
	}

	public void update() {
		for (int i = 0; i < components.size(); i++) {
			components.get(i).update();
			;
		}
	}

	public void add(UIComponent cp) {
		cp.setPanel(this);
		cp.setPos(cp.getX(), cp.getY());
		components.add(cp);
	}

	public void render(Graphics g) {
		g.setColor(backGroundColor);
		g.fillRect(x, y, width, height);

		for (int i = 0; i < components.size(); i++) {
			components.get(i).render(g);
		}

	}

	public String getName() {
		return name;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

}
