package game.com.UI;

public interface UIButtonAction {

	public void perform();
}
