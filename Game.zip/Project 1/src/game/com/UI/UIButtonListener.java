package game.com.UI;

import java.awt.Color;

public class UIButtonListener {
	
	public void enter(UIButton button) {
		
		button.setColor(colorAdjust(button.get_origin_color(), 5, -5));
	}
	
	public void exit(UIButton button) {
		button.setColor(button.get_origin_color());
	}
	
	public void press(UIButton button) {
		button.setColor(colorAdjust(button.get_origin_color(), -50, 0));
	}
	
	public void release(UIButton button) {
		button.setColor(button.get_origin_color());
	}
	
	private Color colorAdjust(Color color, int amount, int al) {
		if(color == null) return new Color(0);
		int red = color.getRed();
		int green = color.getGreen();
		int blue = color.getBlue();
		int alpha = color.getAlpha();
		
		red += amount;
		green += amount;
		blue += amount;
		
		alpha += al;
		return new Color(red, green, blue, alpha);
	}
}
