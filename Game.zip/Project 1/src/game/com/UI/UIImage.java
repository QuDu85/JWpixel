package game.com.UI;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import game.com.Game;


public class UIImage extends UIComponent{
	private int width ;
	private int height ;
	private BufferedImage image;
	public UIImage(int x, int y, String path) {
		super(x,y);
		loadImage(path);
	}
	
	private void loadImage(String path) {
		try {
			image = ImageIO.read(new File(path));
			this.width = image.getWidth();
			this.height = image.getHeight();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		
	}
	
	public void render(Graphics g) {
		g.drawImage(image, x, y, width * Game.scale, height  * Game.scale, null);
	}
}
