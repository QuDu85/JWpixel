package game.com.UI;

import java.awt.Graphics;

import game.com.Game;


public abstract class UIComponent {

	protected int x, y;
	protected UIPanel panel;
	
	public UIComponent() {
		
	}
	
	public UIComponent(int x, int y) {
		this.x = x * Game.scale;
		this.y = y * Game.scale;
	}

	public void update() {
		
	}
	
	public void render(Graphics g) {
		
	}
	
	public void setPanel(UIPanel panel) {
		this.panel = panel;
	}
	
	public void setPos(int x, int y) {
		this.x = panel.getX() + x;
		this.y = panel.getY() + y;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}
