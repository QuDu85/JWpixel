package game.com.UI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import game.com.Game;
import game.com.input.mouse.Mouse;



public class UIButton extends UIComponent{

	protected int width, height;
	protected UIButtonListener buttonListener = new UIButtonListener();
	protected UIButtonAction action;
	protected String text = new String();
	protected int xt, yt;
	protected String font;
	protected Color color;
	protected Color origin_color;
	protected Mouse mouse;
	
	
	protected boolean press = false;
	protected boolean inside = false;
	
	public UIButton() {
		
	}
	
	public UIButton(int x, int y, int width, int height, Color color, UIButtonAction action) {
		super(x, y);
		this.width = width * Game.scale;
		this.height = height * Game.scale;
		this.color = color;
		this.origin_color = color;
		this.action = action;
	}
	
	public void update() {
		
		if(inside()) {
			if(!inside) {
				buttonListener.enter(this);
				inside = true;
			}
			if(mouse.getButton() == MouseEvent.BUTTON1) {
				buttonListener.press(this);
				press = true;
			}
			else if(press == true && mouse.getButton() == MouseEvent.NOBUTTON) {
				press = false;
				buttonListener.release(this);
				action.perform();
				inside = false;
			}
		}
		else {
			if(inside) {
				buttonListener.exit(this);
				inside = false;
			}
			if(mouse.getButton() == MouseEvent.NOBUTTON) {
				press = false;
			}
		}
	}
	
	public boolean inside() {
		int mx = mouse.getX();
		int my = mouse.getY();
		if(mx < x || my < y) {
			return false;
		}
		int w = x + width;
		int h = y + height;
		if(mx < w && my < h) return true;
		else return false;
		
	}
	
	public void setMouse(Mouse mouse) {
		this.mouse = mouse;
	}
	
	public void setText(int xt, int yt, String text, String font) {
		this.xt = xt * Game.scale + x;
		this.yt = yt * Game.scale + y;
		this.text = text;
		this.font = font;
	}
	
	public void setColor(Color color) {
		this.color = color;
	}
	
	public Color get_origin_color() {
		return origin_color;
	}
	
	public void render(Graphics g) {
		
		g.setColor(color);
		g.fillRect(x,y,width,height);
		
		
		if(!text.isBlank()) {	
			g.setColor(new Color(0xdd8abdbb, true));
			g.setFont(new Font(font, Font.PLAIN, height / 2));
			g.drawString(text, xt, yt);
		}
	}

}
