package game.com.UI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import game.com.Game;


public class UIProgressBar extends UIComponent{

	private Color color;
	private Color backColor;
	private int width, height;
	private double progress;
	private double old_progress;
	private String text = new String();
	private String font;
	private int xt ,yt;
	private double speed = 0;
	private boolean decrease=true;
	public UIProgressBar(int x, int y, int width , int height, Color color) {
		super(x,y);
		this.width = width * Game.scale;
		this.height = height * Game.scale;
		this.color = color;
		backColor = new Color(0xff474646, true);
		progress = 0;
		old_progress = progress;
	}

	public void setText(int xt, int yt, String text, String font) {
		this.xt = xt * Game.scale + x;
		this.yt = yt * Game.scale + y;
		
		this.text = text;
		this.font = font;
	}
	
	public void update() {
		if(speed == 0) {
			old_progress = progress;
			return;
		}
		if(old_progress>progress)
			old_progress-=speed;
		if(progress==1) old_progress=1;
		if(old_progress<progress)
			old_progress+=speed;
		if(progress==0) old_progress=0;
	}
	
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	
	public void setProgress(double progress) {
		this.progress = progress;
		old_progress=progress;
	}
	
	public void render(Graphics g) {
		g.setColor(backColor);
		g.fillRect(x, y, width, height);
		
		g.setColor(color);
		g.fillRect(x, y, (int)((double)width * old_progress), (int)height);
		
		if(!text.isBlank()) {
			g.setFont(new Font(font,Font.PLAIN,height * 3 / 4));
			g.setColor(new Color(0xeeb7d7d6,true));
			g.drawString(text, xt, yt);			
		}
	}
	
}
