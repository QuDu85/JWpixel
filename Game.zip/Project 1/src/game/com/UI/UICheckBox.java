package game.com.UI;

import java.awt.Color;
import java.awt.event.MouseEvent;

import game.com.Game;



public class UICheckBox extends UIButton{
	
	protected UIButtonAction pressAction;
	protected UIButtonAction releaseAction;
	
	public UICheckBox() {
		
	}
	
	public UICheckBox(int x, int y, int width, int height, Color color, boolean press, UIButtonAction pressAction, UIButtonAction releaseAction) {
		super();
		this.x = x * Game.scale;
		this.y = y * Game.scale;
		this.width = width * Game.scale;
		this.height = height * Game.scale;
		this.color = color;
		this.origin_color  = color;
		this.press = press;
		this.pressAction = pressAction;
		this.releaseAction = releaseAction;
		
	}
	
	public UICheckBox(int x, int y, int width, int height, Color color , boolean press, UIButtonAction action) {
		super(x, y, width, height, color, action);
		this.press = press;
	}
	
	public void setStat(boolean press) {
		this.press = press;
	}
	
	public void update() {
		
		if(inside()) {
			if(!inside) {
				if(!press)
					buttonListener.enter(this);
				inside = true;
			}
			if(mouse.getButton() == MouseEvent.BUTTON1) {
				if(!press) buttonListener.press(this);
				press = true;
				pressAction.perform();
				inside = false;

			}
		}
		else {
			if(inside) {
				if(!press)
					buttonListener.exit(this);
				inside = false;
			}
		}
		if(press == false) {
			buttonListener.release(this);
			releaseAction.perform();
		}
		else buttonListener.press(this);
	}
	
}
