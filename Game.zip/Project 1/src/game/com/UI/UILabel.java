package game.com.UI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class UILabel extends UIComponent{

	private String text;
	private Font font;
	private Color color;
	public UILabel(int x, int y,Color color, Font font, String text) {
		super(x,y);
		this.text = text;
		this.font = font;
		this.color = color;
	}
	
	
	public void update() {
		
	}
	
	public void render(Graphics g) {
		g.setColor(color);
		g.setFont(font);
		g.drawString(text, x, y);
	}
	
}
