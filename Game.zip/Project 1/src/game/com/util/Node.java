package game.com.util;

public class Node {
	private Vec v;
	private Node parent;
	private double path;
	private double dis;
	private double total;
	
	public Node(Vec v, Node parent, double path, double dis) {
		this.v=v;
		this.parent=parent;
		this.path=path;
		this.dis=dis;
		this.total=path+dis;
	}
	
	public Node() {
		
	}
	
	public boolean equals(Node n) {
		if(n.getV().equals(v)) return true;
		return false;
	}
	
	public Vec getV() {
		return v;
	}
	public void setV(Vec v) {
		this.v = v;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public double getPath() {
		return path;
	}
	public void setPath(int path) {
		this.path = path;
	}
	public double getDis() {
		return dis;
	}
	public void setDis(int dis) {
		this.dis = dis;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
	
}
