package game.com.util;

public class Vec {
	private double x,y;
	
	public Vec(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public Vec() {
		
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public double distance(Vec v) {
		double dx = x-v.getX();
		double dy = y-v.getY();
		return Math.sqrt(dx*dx+dy*dy);
	}
	public boolean equals(Vec v) {
		if(x==v.getX() && y==v.getY()) return true;
		else return false;
	}
	
}
