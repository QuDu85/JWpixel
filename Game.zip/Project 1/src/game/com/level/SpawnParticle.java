package game.com.level;

import game.com.level.Particle.EFFECT;
import game.com.level.entity.stat.Exp;


public class SpawnParticle{
	
	public SpawnParticle(double x, double y,  int color, int size, int amount, Level level, EFFECT effect,double  time) {
		for(int i=0; i<amount; i++)
			level.add(new Particle(x, y, color, size, effect, time));
	}
	
	public SpawnParticle(double x, double y, int size, int amount, Level level, EFFECT effect,double  time, int exp) {
		for(int i=0; i<amount; i++)
			level.add(new Exp(x, y, size, effect, time, exp));
	}
	
	
}
