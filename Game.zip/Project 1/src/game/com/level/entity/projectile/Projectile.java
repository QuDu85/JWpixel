package game.com.level.entity.projectile;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.Mob.DIRECTION;
import game.com.screen.Screen;

public abstract class Projectile extends Entity {
	protected double xd, yd;
	protected double x0, y0;
	protected int range;
	protected int rateOfFire;
	protected double speed;
	private Entity entity;

	public Projectile(double x, double y, double xd, double yd, Entity entity) {
		this.x = x;
		this.y = y;
		this.x0 = x;
		this.y0 = y;
		this.xd = xd;
		this.yd = yd;
		this.entity = entity;
	}

	public DIRECTION getOpsDirection() {
		if (xd == 0 && yd == -1)
			return DIRECTION.DOWN;
		else if (xd == 0 && yd == 1)
			return DIRECTION.UP;
		else if (xd == -1 && yd == 0)
			return DIRECTION.RIGHT;
		else if (xd == 1 && yd == 0)
			return DIRECTION.LEFT;
		return null;
	}

	
	
	public Entity getsrcEntity() {
		return entity;
	}

	public double getX0() {
		return x0;
	}

	public double getY0() {
		return y0;
	}

	public int getRange() {
		return range;
	}

	public int getRateOfFire() {
		return rateOfFire;
	}

	public double getSpeed() {
		return speed;
	}

	public Entity getEntity() {
		return entity;
	}

	public void setXd(double xd) {
		this.xd = xd;
	}

	public void setYd(double yd) {
		this.yd = yd;
	}

	public void setX0(double x0) {
		this.x0 = x0;
	}

	public void setY0(double y0) {
		this.y0 = y0;
	}

	public void setRange(int range) {
		this.range = range;
	}

	public void setRateOfFire(int rateOfFire) {
		this.rateOfFire = rateOfFire;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}

	public double getXd() {
		return xd;
	}

	public double getYd() {
		return yd;
	}

	public Projectile() {

	}

	public void update() {
		if (outOfRange() || collision(x, y, xd * speed, yd * speed)) {
			level.remove(this);

		} else
			move();
	}

	public boolean collision(double x, double y, double x0, double y0) {
		int xt;
		int yt = ((int) (y + y0 + height / 2)) >> 4;
		for (int i = 0; i < 2; i++) {
			xt = ((int) (x + x0 - width / 2 + i * width)) >> 4;
			if (level.getTile(xt, yt).isSolid())
				return true;
		}
		return false;
	}

	public void move() {
		x += xd * speed;
		y += yd * speed;

	}

	public boolean outOfRange() {
		double dx = this.x - x0;
		double dy = this.y - y0;
		if (Math.sqrt(dx * dx + dy * dy) > range)
			return true;
		else
			return false;
	}

	public void render(Screen screen) {

	}
}
