package game.com.level.entity.projectile;

import game.com.level.entity.Entity;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class DetectProjectile extends Projectile{
	private Entity target;

	public DetectProjectile(double x, double y, double xd, double yd, Entity entity) {
		super(x, y, xd, yd, entity);
//		this.sprite=new Sprite(0,32,16,16,SpriteSheet.projectile);
		
	}
	
	public DetectProjectile() {
		
	}

	public Entity getTarget() {
		return target;
	}
	
//	public void update() {
//		if(outOfRange()) level.remove(this);
//		else move();
//	}
	
	public void render(Screen screen) {
//		screen.renderEntity((int)(x-sprite.getWidth()/2),(int)(y-sprite.getHeight()/2),this);
	}


	public void setTarget(Entity target) {
		this.target = target;
	}
	
	
}
