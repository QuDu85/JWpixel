package game.com.level.entity.projectile;

import game.com.level.entity.Entity;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class CollisionProjectile extends Projectile{
	
	private int damage;
	
	public int getDamage() {
		return damage;
	}

	public CollisionProjectile(double x, double y, int xd, int yd, int range, Entity e) {
		super(x,y,xd,yd,e);
		this.range=range;
		this.speed=7;
		this.damage=e.getCollisionDamage();
		this.sprite=new Sprite(32,0,16,16,SpriteSheet.projectile);
	}
	
	public void update() {
		if(outOfRange()) level.remove(this);
		move();
	}
	
	public void render(Screen screen) {
		screen.renderEntity((int)(x-sprite.getWidth()/2),(int)(y-sprite.getHeight()/2),this);	
	}
	
}
