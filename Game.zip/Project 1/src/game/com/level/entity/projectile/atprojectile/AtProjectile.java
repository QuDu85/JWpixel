package game.com.level.entity.projectile.atprojectile;

import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.Entity;
import game.com.level.entity.projectile.Projectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class AtProjectile extends Projectile{
	private int damage;
	protected Sprite vsprite= new Sprite(16,0,16,16,SpriteSheet.projectile);
	protected Sprite hsprite= new Sprite(16,16,16,16,SpriteSheet.projectile);
	protected AniSprite animation;
	
	public AtProjectile(double x, double y, double xd, double yd, Entity entity, Sprite hsprite, Sprite vsprite) {
		super(x,y,xd,yd,entity);
		if(xd==0) this.sprite=vsprite;
		else this.sprite=hsprite;
		damage = entity.getDamage();
		range = entity.getRange();
		speed = entity.getProjectilespeed();
	}
	
	public AtProjectile(double x, double y, double xd, double yd, Entity entity, AniSprite hsprite, AniSprite vsprite) {
		super(x,y,xd,yd,entity);
		if(xd==0) this.animation=vsprite;
		else this.animation=hsprite;
		damage = entity.getDamage();
		range = entity.getRange();
		speed = entity.getProjectilespeed();
	}
	
	public AtProjectile(double x, double y, double xd, double yd, Entity entity) {
		super(x,y,xd,yd,entity);
		
		damage = entity.getDamage();
		range = entity.getRange();
		speed = entity.getProjectilespeed();
	}
	
	public AtProjectile() {
		
	}
	
	public int getDamage() {
		return damage;
	}
	
	public void update() {
		if(outOfRange() || collision(x,y,xd*speed,yd*speed)) {
			level.remove(this);
			if(collision(x,y,xd*speed,yd*speed)) {
				SpawnParticle sp = new SpawnParticle(x+xd*speed,y+yd*speed,0xc8dc31,2,10,level,EFFECT.RANDOM,20);
			}
		}
		else move();
		if(animation!=null) animation.update();
	}
	
	public void render(Screen screen) {
		if(sprite!=null)
		screen.renderEntity((int)(x-sprite.getWidth()/2),(int)(y-sprite.getHeight()/2),this);
		else if(animation!=null) {
			this.sprite = animation.frame();
			screen.renderEntity((int) (x - sprite.getWidth() / 2), (int) (y - z - sprite.getHeight() / 2), this);
		}
			
	}

	public double getSpeed() {
		return speed;
	}
}
