package game.com.level.entity;

import game.com.level.Level;
import game.com.level.spritesheet.Sprite;
import game.com.levelsys.LevelSys;
import game.com.screen.Screen;
import game.com.util.Vec;

public abstract class Entity {
	protected double x, y, z;
	protected int width, height;
	protected int collisionDamage;
	protected int range = 400;
	protected int projectilespeed = 7;
	protected int damage = 50;

	protected Sprite sprite;
	protected LevelSys sys;
	protected Level level;
	protected Screen screen;

	public int getRange() {
		return range;
	}

	public void setRange(int range) {
		this.range = range;
	}

	public int getProjectilespeed() {
		return projectilespeed;
	}

	public void setProjectilespeed(int projectilespeed) {
		this.projectilespeed = projectilespeed;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public int getCollisionDamage() {
		return collisionDamage;
	}

	public void setCollisionDamage(int collisionDamage) {
		this.collisionDamage = collisionDamage;
	}

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void setZ(double z) {
		this.z = z;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	public Entity() {

	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Sprite getSprite() {
		return sprite;
	}

	public LevelSys getSys() {
		return sys;
	}

	public double distance(Entity e) {
		double dx = x - e.getX();
		double dy = y - e.getY();
		return Math.sqrt(dx * dx + dy * dy);
	}

	public void setSys(LevelSys sys) {
		this.sys = sys;
	}

	public void setSprite(Sprite sprite) {
		this.sprite = sprite;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public void setPos(int x, int y) {
		this.x = x << 4;
		this.y = y << 4;
	}

	public Entity(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public void update() {

	}

	public void render(Screen screen) {

	}
}
