package game.com.level.entity.mob.bot;

import java.util.ArrayList;
import java.util.List;

import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.mob.Mob;
import game.com.level.entity.projectile.CollisionProjectile;
import game.com.level.entity.projectile.DetectProjectile;
import game.com.level.entity.projectile.Projectile;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Minion extends Mob {

	protected final int defaultspeed = 1;
	protected final int defaultgetAttackTime = 10;
	protected final int defaultvision = 400;
	private final int defaultAttackRange = 100;
	protected final int defaultAtSignalFrequency = 10;
	protected final int defaultFireRate = 30;
	protected int attackFrame = 3;
	protected int totalexp;

	protected AniSprite bot_up = new AniSprite(32, 64, new SpriteSheet(0, 0, 32, 320, SpriteSheet.ranged),
			PATTERN.VERTICAL);
	protected AniSprite bot_down = new AniSprite(32, 64, new SpriteSheet(32, 0, 32, 320, SpriteSheet.ranged),
			PATTERN.VERTICAL);
	protected AniSprite bot_left = new AniSprite(32, 64, new SpriteSheet(64, 0, 32, 320, SpriteSheet.ranged),
			PATTERN.VERTICAL);
	protected AniSprite bot_right = new AniSprite(32, 64, new SpriteSheet(96, 0, 32, 320, SpriteSheet.ranged),
			PATTERN.VERTICAL);
	protected List<AniSprite> move = new ArrayList<>();

	protected AniSprite bot_attack_up = new AniSprite(32, 32, new SpriteSheet(32, 0, 32, 96, SpriteSheet.playershoot),
			PATTERN.VERTICAL);
	protected AniSprite bot_attack_down = new AniSprite(32, 32, new SpriteSheet(0, 0, 32, 96, SpriteSheet.playershoot),
			PATTERN.VERTICAL);
	protected AniSprite bot_attack_left = new AniSprite(32, 32, new SpriteSheet(96, 0, 32, 96, SpriteSheet.playershoot),
			PATTERN.VERTICAL);
	protected AniSprite bot_attack_right = new AniSprite(32, 32,
			new SpriteSheet(64, 0, 32, 96, SpriteSheet.playershoot), PATTERN.VERTICAL);
	protected List<AniSprite> attack = new ArrayList<>();

	protected AniSprite anisprites;
	protected List<AniSprite> curAni = new ArrayList<>();

	public enum PATTERN {
		HORIZONTAL, VERTICAL
	}

	protected PATTERN pattern;
	protected int time = 0;
	protected int getAttackTime;
	protected DetectProjectile atSignal = new DetectProjectile();

	protected double xt, yt, zt;
	protected int atSignalFrequency = defaultAtSignalFrequency;
	protected int rateOfFire = defaultFireRate;

	public Minion() {

	}

	public Minion(int x, int y, int width, int height, PATTERN pattern) {
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;
		this.pattern = pattern;
		state = STATE.STAND;
		dir = DIRECTION.DOWN;

		move.add(bot_up);
		move.add(bot_down);
		move.add(bot_left);
		move.add(bot_right);

		attack.add(bot_attack_up);
		attack.add(bot_attack_down);
		attack.add(bot_attack_left);
		attack.add(bot_attack_right);

		for (int i = 0; i < attack.size(); i++) {
			attack.get(i).setFPS(200 / defaultFireRate);
		}

		speed = defaultspeed;
		maxhealth = 150;
		health = maxhealth;
		range = 400;
		damage = 50;
		projectilespeed = 7;
		curAni = move;
		anisprites = curAni.get(1);
		totalexp = 200;
	}

	public void collisionSignal() {
		level.add(new CollisionProjectile(x, y, 1, 0, width / 3, this));
		level.add(new CollisionProjectile(x, y, -1, 0, width / 3, this));
		level.add(new CollisionProjectile(x, y, 0, -1, height / 3, this));
		level.add(new CollisionProjectile(x, y, 0, 1, height / 3, this));

	}

	public void aniControl() {
		if (state == STATE.WALKING)
			curAni = move;
		else if (state == STATE.ATTACK)
			curAni = attack;
		else if (state == STATE.STAND) {
			curAni = move;
		}
		if (dir == DIRECTION.UP)
			anisprites = curAni.get(0);
		if (dir == DIRECTION.DOWN)
			anisprites = curAni.get(1);
		if (dir == DIRECTION.LEFT)
			anisprites = curAni.get(2);
		if (dir == DIRECTION.RIGHT)
			anisprites = curAni.get(3);

		anisprites.update();

		if (state == STATE.STAND) {
			anisprites.setFrame(0);
		}
	}

	public void dirControl() {
		if (x0 < 0)
			dir = DIRECTION.LEFT;
		if (x0 > 0)
			dir = DIRECTION.RIGHT;
		if (y0 < 0)
			dir = DIRECTION.UP;
		if (y0 > 0)
			dir = DIRECTION.DOWN;
	}

	public void moving() {
		x0 = 0;
		y0 = 0;
		if (time < 120) {
			if (pattern == PATTERN.HORIZONTAL) {
				x0 += speed;
				dir = DIRECTION.RIGHT;
			} else {
				y0 += speed;
				dir = DIRECTION.DOWN;
			}
		} else if (time > 120 && time < 240) {
			if (pattern == PATTERN.HORIZONTAL) {
				x0 -= speed;
				dir = DIRECTION.LEFT;
			} else {
				y0 -= speed;
				dir = DIRECTION.UP;
			}
		}
		move(x0, y0);
		anisprites.setFPS(speed * 2);
	}

	public void getAttack(AtProjectile p) {
		if (p.getsrcEntity() != this) {
			state = STATE.GETATTACK;
//			dir=p.getOpsDirection();
			getAttackTime = defaultgetAttackTime;
			minusHealth(p.getDamage());
			x0 = p.getXd() * p.getSpeed();
			y0 = p.getYd() * p.getSpeed();
			z0 = p.getSpeed() / 2;
			xt = Math.abs(x0);
			yt = Math.abs(y0);
			zt = Math.abs(z0);
			if (health <= 0) {
				level.remove(this);
				SpawnParticle sp = new SpawnParticle(x, y, 2, 50, level, EFFECT.RANDOM, 200, totalexp / 50);
			}

			level.remove(p);
		}
	}

	public void getAttackEffect() {
		if (getAttackTime <= 0 && state == STATE.GETATTACK)
			state = STATE.STAND;

		if (state == STATE.GETATTACK) {
			x0 -= sign(x0) * xt / defaultgetAttackTime;
			y0 -= sign(y0) * yt / defaultgetAttackTime;
			z += z0;
			z0 -= zt * 2 / defaultgetAttackTime;
			move(x0, y0);
			SpawnParticle sp = new SpawnParticle(x, y, 0x2f7aeb, 2, 10, level, EFFECT.FALLING, 20);
			SpawnParticle sp2 = new SpawnParticle(x, y, 0xbcc6d4, 2, 10, level, EFFECT.FALLING, 20);

		} else {
			z = 0;

		}
	}

	public void time() {
		time = (time + 1) % 240;
		getAttackTime--;
		if (getAttackTime < -1000)
			getAttackTime = -1;
		atSignalFrequency--;
		if (atSignalFrequency < -1000)
			atSignalFrequency = -1;
		rateOfFire--;
		if (rateOfFire < -1000)
			rateOfFire = -1;
	}

	public void getSignal() {
		List<Projectile> list = this.level.detectProjectile(this);
		if (!list.isEmpty())
			for (int i = 0; i < list.size(); i++)
				if (list.get(i) instanceof AtProjectile)
					getAttack((AtProjectile) list.get(i));
	}

	public void attackSignal() {
		atSignal = null;
		if (dir == DIRECTION.UP)
			atSignal = new DetectProjectile(x, y, 0, -1, this);
		if (dir == DIRECTION.DOWN)
			atSignal = new DetectProjectile(x, y, 0, 1, this);
		if (dir == DIRECTION.LEFT)
			atSignal = new DetectProjectile(x, y, -1, 0, this);
		if (dir == DIRECTION.RIGHT)
			atSignal = new DetectProjectile(x, y, 1, 0, this);

		atSignal.setRange(defaultvision);
		atSignal.setSpeed(10);
		level.add(atSignal);
	}

	public void attack() {
		if (atSignalFrequency <= 0 && state != STATE.ATTACK) {
			attackSignal();
			atSignalFrequency = defaultAtSignalFrequency;
		}
		if (atSignal.getTarget() != null && distance(atSignal.getTarget()) <= range)
			if (state != STATE.ATTACK)
				state = STATE.ATTACK;
		if (state == STATE.ATTACK) {
			if (curAni == attack && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
				if (dir == DIRECTION.UP)
					level.add(new AtProjectile(x, y, 0, -1, this));
				if (dir == DIRECTION.DOWN)
					level.add(new AtProjectile(x, y, 0, 1, this));
				if (dir == DIRECTION.LEFT)
					level.add(new AtProjectile(x, y, -1, 0, this));
				if (dir == DIRECTION.RIGHT)
					level.add(new AtProjectile(x, y, 1, 0, this));
				rateOfFire = defaultFireRate;
			}
			if (anisprites.getFrame() == anisprites.getLength() - 1) {
				anisprites.setFrame(0);
				state = STATE.STAND;
			}
		}
	}

	public void update() {
		time();
		getSignal();

		if (state != STATE.GETATTACK) {
			if (state != STATE.ATTACK)
				moving();
			attack();
		}
		dirControl();
		getAttackEffect();
		collisionSignal();
		aniControl();
	}

	public void render(Screen screen) {
		this.sprite = anisprites.frame();
		screen.renderEntity((int) (x - sprite.getWidth() / 2), (int) (y - z - sprite.getHeight() / 2), this);

	}
}
