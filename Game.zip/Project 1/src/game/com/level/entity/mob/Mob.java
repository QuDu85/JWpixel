package game.com.level.entity.mob;

import java.util.List;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.player.Player;
import game.com.level.gate.Gate;

public class Mob extends Entity{
	
	public enum DIRECTION {
		UP, DOWN, LEFT, RIGHT
	}
	
	public enum STATE{
		STAND, WALKING, ATTACK, GETATTACK, COLLISION, STAGGER
	}
	
	protected double x0,y0,z0;
	protected DIRECTION dir;
	protected STATE state;
	protected double speed;
	protected int maxhealth;
	protected int health;
	protected boolean walking=false;
	protected boolean passable=true;
	protected int time=0;
	
	
	public Mob() {
		
	}
	
	public void move(double x0, double y0) {

		
		if(x0!=0 || y0!=0) {
			changeLevel();
			while(x0 != 0) {
				if(Math.abs(x0)>1) {
					if(!collision(x,y,sign(x0),y0,width,height)) {
						x+=sign(x0);
					}
					x0-=sign(x0);
				}else {
					if(!collision(x,y,x0,y0,width,height)) {
						x+=x0;
					}		
					x0=0;
				}
			}
			
			while(y0 != 0) {
				if(Math.abs(y0)>1) {
					if(!collision(x,y,x0,sign(y0),width,height)) {
						y+=sign(y0);
					}
					y0-=sign(y0);
				}
				else {
					if(!collision(x,y,x0,y0,width,height)) {
						y+=y0;
					}
					y0=0;
				}
			}if(state!=STATE.GETATTACK && state!=STATE.COLLISION && state!=STATE.ATTACK)
				state = STATE.WALKING;
		}else state = STATE.STAND;
		
	}
	
	public double getSpeed() {
		return speed;
	}

	public STATE getState() {
		return state;
	}
	
	public void setState(STATE state) {
		this.state=state;
	}
	
	public double sign(double x) {
		if(x>0) return 1;
		else if(x<0) return -1;
		return 0;
	}
	
	public void changeLevel() {
		
		List<Gate> list =level.gates();
		if(!list.isEmpty()) {
			if(time>=60)
			for(int i=0;i<list.size(); i++) {
				Gate g=list.get(i);
					if(x>(g.getX()<<4) && x<(g.getX()<<4)+g.getWidth() && y+height/2>(g.getY()<<4) && y+height/2<(g.getY()<<4)+g.getHeight()) {
							if(this instanceof Player) {
								sys.change(this,g);
								time=0;     
						}
					
					}
			}
		}
			
	}
	
	public boolean collision(double x, double y, double x0, double y0, int width, int height) {
		int xt;
		int yt= ((int) (y +y0 +height/2)) >>4;
		for(int i=0;i<2;i++) {
			xt=((int)(x+x0-width/2+i*width))>>4;
			if(level.getTile(xt, yt).isSolid()) return true;
		}
		return false;
	}
	
	public void minusHealth(int damage) {
		this.health-=damage;
	}
	
	public Mob(double x, double y) {
		super(x, y);
	}
	
}
