package game.com.level.entity.mob.bot;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.Mob.DIRECTION;
import game.com.level.entity.mob.Mob.STATE;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.mob.player.Player;
import game.com.level.entity.projectile.DetectProjectile;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;

public class BalancedBot extends Minion{
	private final int defaultSensitive = 5;
	private int sensitive = defaultSensitive;
	protected int defaultTraceTime =360;
	private final int defaultSignalFrequency=60;

	
	
	protected int signalFrequency = 0;
	private int traceTime = 0;
	protected boolean isTracing = false;
	
	
	DetectProjectile dt = new DetectProjectile();

	public BalancedBot() {
		
	}
	
	public BalancedBot(int x, int y, int width, int height, PATTERN pattern) {
		super(x, y, width, height, pattern);
		
	}
	
	public void moving() {
		x0=0;
		y0=0;
		if(!trace()) {
			if(time<120) {
				if(pattern==PATTERN.HORIZONTAL) {
					x0+=speed;
					dir=DIRECTION.RIGHT;
				}else {
					y0+=speed;
					dir=DIRECTION.DOWN;
				}
			}else if(time>120 && time<240) {
				if(pattern==PATTERN.HORIZONTAL) {
					x0-=speed;
					dir=DIRECTION.LEFT;
				}
				else {
					y0-=speed;
					dir=DIRECTION.UP;
				}
			}
			move(x0,y0);
			anisprites.setFPS(speed * 2);
			
		}
	}
	
	public boolean trace() {
		if(dt.getTarget()!=null && traceTime<0) {
			isTracing=true;
			traceTime=defaultTraceTime;
		}
		if(isTracing) {
			Entity e =dt.getTarget();
			isTracing=true;
			if(x-e.getX() >2 && !collision(x,y,-speed,0,width,height)) {
				x0-=speed;
				dir = DIRECTION.LEFT;
			}
			else if(e.getX() -x>2  && !collision(x,y,speed,0,width,height)) {
				x0+=speed;
				dir=DIRECTION.RIGHT;
			}
			else if(y-e.getY()>2 && !collision(x,y,0,-speed,width,height)) {
				y0-=speed;
				dir=DIRECTION.UP;
			}
			else if(e.getY()-y>2 && !collision(x,y,0,speed,width,height)) {
				y0+=speed;
				dir=DIRECTION.DOWN;
			}
			
			move(x0,y0);
			
			if(traceTime<=0) isTracing=false;
		}
		return isTracing;
	}
	
	public void sendSignal() {
		dt=null;
		
		if(dir==DIRECTION.UP) dt = new DetectProjectile(x,y,0,-1,this);
		if(dir==DIRECTION.DOWN) dt = new DetectProjectile(x,y,0,1,this);
		if(dir==DIRECTION.LEFT) dt = new DetectProjectile(x,y,-1,0,this);
		if(dir==DIRECTION.RIGHT) dt = new DetectProjectile(x,y,1,0,this);
		
		dt.setRange(defaultvision);
		dt.setSpeed(sensitive);
		level.add(dt);
		
		signalFrequency=defaultSignalFrequency;
		
	}
	
	
	
	public void time() {
		time=(time+1)%240;
		getAttackTime--;
		if(getAttackTime<-1000)
			getAttackTime=-1;
		signalFrequency--;
		if(signalFrequency<-1000)
			signalFrequency=-1;
		traceTime--;
		if(traceTime<-1000)
			traceTime=-1;
		atSignalFrequency--;
		if(atSignalFrequency<-1000)
			atSignalFrequency=-1;
		rateOfFire--;
		if(rateOfFire<-1000)
			rateOfFire=-1;
	}
	
	public void update() {
		time();
		aniControl();
		getSignal();
		if(signalFrequency<0 && !isTracing)
			sendSignal();
		getSignal();
		if(state!=STATE.GETATTACK) {
			if(state!=STATE.ATTACK)
				moving();
			attack();
		}
		collisionSignal();
		getAttackEffect();
	}
}
