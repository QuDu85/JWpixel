package game.com.level.entity.mob.bot;

import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.levelsys.LevelSys.MODE;
import game.com.screen.Screen;

public class Tank extends BalancedBot{
	
	
	public Tank(int x, int y, int width, int height, MODE mode) {
		bot_up = new AniSprite(64,64,new SpriteSheet(0,0,64,384, SpriteSheet.tank), PATTERN.VERTICAL);
		bot_down = new AniSprite(64,64,new SpriteSheet(64,0,64,384, SpriteSheet.tank), PATTERN.VERTICAL);
		bot_left = new AniSprite(64,64,new SpriteSheet(128,0,64,384, SpriteSheet.tank), PATTERN.VERTICAL);
		bot_right = new AniSprite(64,64,new SpriteSheet(192,0,64,384, SpriteSheet.tank), PATTERN.VERTICAL);
		
		bot_attack_up = new AniSprite(64, 64,
				new SpriteSheet(0, 0, 64, 256, SpriteSheet.tankattack), PATTERN.VERTICAL);
		bot_attack_down = new AniSprite(64, 64,
				new SpriteSheet(64, 0, 64, 256, SpriteSheet.tankattack), PATTERN.VERTICAL);
		bot_attack_left = new AniSprite(64, 64,
				new SpriteSheet(128, 0, 64, 256, SpriteSheet.tankattack), PATTERN.VERTICAL);
		bot_attack_right = new AniSprite(64, 64,
				new SpriteSheet(192, 0, 64, 256, SpriteSheet.tankattack), PATTERN.VERTICAL);
		
		this.x=x<<4;
		this.y=y<<4;
		this.width=width;
		this.height=height;
		state = STATE.STAND;
		dir = DIRECTION.DOWN;
		
		move.add(bot_up);
		move.add(bot_down);
		move.add(bot_left);
		move.add(bot_right);
		
		attack.add(bot_attack_up);
		attack.add(bot_attack_down);
		attack.add(bot_attack_left);
		attack.add(bot_attack_right);

		for (int i = 0; i < attack.size(); i++) {
			attack.get(i).setFPS(200 / defaultFireRate);
		}
		
		collisionDamage=30;
		speed=defaultspeed;
		if(mode==MODE.HARD) {
			maxhealth=400;
			defaultTraceTime =500;			
		}else{
			maxhealth=350;
			defaultTraceTime =360;			
			
		}
		health=maxhealth;
		curAni = move;
		range=35;
		attackFrame=2;
		totalexp=150;
		anisprites= curAni.get(1);
	}
	
	
	public void getAttack(AtProjectile p) {
		if(p.getsrcEntity()!=this) {
			if(p.getOpsDirection()==dir) {
				SpawnParticle blocked = new SpawnParticle(x,y, 0xa6eae1, 2, 15, level, EFFECT.RANDOM, 20);
			}else {
				state=STATE.GETATTACK;
//				dir=p.getOpsDirection();
				getAttackTime=defaultgetAttackTime;
				minusHealth(p.getDamage());
				x0=p.getXd()*p.getSpeed();
				y0=p.getYd()*p.getSpeed();
				z0=p.getSpeed()/2;
				xt=Math.abs(x0);
				yt=Math.abs(y0);;
				zt=Math.abs(z0);;
				if(health<=0) {
					level.remove(this);
					SpawnParticle sp = new SpawnParticle(x, y, 2, 50, level, EFFECT.RANDOM, 200, totalexp/50);
				}
			}
				
			level.remove(p);
		}
	}
	
	public void scan() {
		x0=0;
		y0=0;
		if(!trace()) {
			if(time<60) 
				dir=DIRECTION.UP;
			else if(time<120)
				dir=DIRECTION.RIGHT;
			else if(time<180)
				dir=DIRECTION.DOWN;
			else
				dir=DIRECTION.LEFT;
			anisprites.setFPS(speed * 2);
			
		}
	}
	
	
	public boolean collision(double x, double y, double x0, double y0, int width, int height) {
		int xt;
		int yt= ((int) (y +y0 +height/2)) >>4;
		for(int i=0;i<2;i++) {
			xt=((int)(x+x0-5+i*10))>>4;
			if(level.getTile(xt, yt).isSolid()) return true;
		}
		return false;
	}
	
	public void update() {
		time();
		aniControl();
		getSignal();
		if(signalFrequency<0 && !isTracing)
			sendSignal();
		getSignal();
		if(state!=STATE.GETATTACK) {
			if(state!=STATE.ATTACK)
				scan();
			attack();
		}
		getAttackEffect();
	}
	
	public void render(Screen screen) {
		this.sprite=anisprites.frame();
		screen.renderEntity((int)(x-sprite.getWidth()/2),(int)(y-z-sprite.getHeight()/2),this);

	}
	
}
