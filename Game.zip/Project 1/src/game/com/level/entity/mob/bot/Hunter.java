package game.com.level.entity.mob.bot;

import java.util.ArrayList;
import java.util.List;

import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.levelsys.LevelSys.MODE;

public class Hunter extends EliteBot{
	AniSprite bot_punch_up = new AniSprite(32, 32,
			new SpriteSheet(0, 0, 32, 128, SpriteSheet.hunterpunch), PATTERN.VERTICAL);
	AniSprite bot_punch_down = new AniSprite(32, 32,
			new SpriteSheet(32, 0, 32, 128, SpriteSheet.hunterpunch), PATTERN.VERTICAL);
	AniSprite bot_punch_left = new AniSprite(32, 32,
			new SpriteSheet(64, 0, 32, 128, SpriteSheet.hunterpunch), PATTERN.VERTICAL);
	AniSprite bot_punch_right = new AniSprite(32, 32,
			new SpriteSheet(96, 0, 32, 128, SpriteSheet.hunterpunch), PATTERN.VERTICAL);

	private static final Sprite bulletup= new Sprite(16,16,16,16,SpriteSheet.balancedprojectile);
	private static final Sprite bulletforward= new Sprite(16,0,16,16,SpriteSheet.balancedprojectile);
	
	private List<AniSprite> punch = new ArrayList<>();

	private int punchrange=30;
	private int shootrange;
	private int punchdamage;
	private int shootdamage;
	
	public Hunter(int x, int y, int width, int height, PATTERN pattern, MODE mode) {
		bot_up = new AniSprite(32,32,new SpriteSheet(0,0,32,128, SpriteSheet.hunter), PATTERN.VERTICAL);
		bot_down = new AniSprite(32,32,new SpriteSheet(32,0,32,128, SpriteSheet.hunter), PATTERN.VERTICAL);
		bot_left = new AniSprite(32,32,new SpriteSheet(64,0,32,128, SpriteSheet.hunter), PATTERN.VERTICAL);
		bot_right = new AniSprite(32,32,new SpriteSheet(96,0,32,128, SpriteSheet.hunter), PATTERN.VERTICAL);
		
		bot_attack_up = new AniSprite(32, 32,
				new SpriteSheet(0, 0, 32, 160, SpriteSheet.huntershoot), PATTERN.VERTICAL);
		bot_attack_down = new AniSprite(32, 32,
				new SpriteSheet(32, 0, 32, 160, SpriteSheet.huntershoot), PATTERN.VERTICAL);
		bot_attack_left = new AniSprite(32, 32,
				new SpriteSheet(64, 0, 32, 160, SpriteSheet.huntershoot), PATTERN.VERTICAL);
		bot_attack_right = new AniSprite(32, 32,
				new SpriteSheet(96, 0, 32, 160, SpriteSheet.huntershoot), PATTERN.VERTICAL);
		
		
		this.x=x<<4;
		this.y=y<<4;
		this.width=width;
		this.height=height;
		this.pattern=pattern;
		state = STATE.STAND;
		dir = DIRECTION.DOWN;
		
		move.add(bot_up);
		move.add(bot_down);
		move.add(bot_left);
		move.add(bot_right);
		
		attack.add(bot_attack_up);
		attack.add(bot_attack_down);
		attack.add(bot_attack_left);
		attack.add(bot_attack_right);
		
		punch.add(bot_punch_up);
		punch.add(bot_punch_down);
		punch.add(bot_punch_left);
		punch.add(bot_punch_right);

		for (int i = 0; i < attack.size(); i++) {
			attack.get(i).setFPS(200 / defaultFireRate);
			punch.get(i).setFPS(200 / defaultFireRate);
		}
		shootrange=range;
		collisionDamage=10;
		speed=2;
		if(mode==MODE.HARD) {
			maxhealth=250;
			punchdamage=40;
			shootdamage=50;
			vision=200;
			interval=60;
		}else {
			maxhealth=200;
			punchdamage=30;
			shootdamage=40;
			vision=100;
			interval=30;
		}
		health=maxhealth;
		totalexp=120;
		curAni = move;
		anisprites= curAni.get(1);
	}
	
	public void aniControl() {
		System.out.println(state);
		if (state == STATE.WALKING)
			curAni = move;
		else if (state == STATE.ATTACK) {
			 if(distance(atSignal.getTarget())<punchrange)
				curAni = punch;
			 else if(distance(atSignal.getTarget())>=punchrange && distance(atSignal.getTarget())<=shootrange)
				 curAni=attack;
		}
		else if (state == STATE.STAND) {
			curAni = move;
		}
		if (dir == DIRECTION.UP)
			anisprites = curAni.get(0);
		if (dir == DIRECTION.DOWN)
			anisprites = curAni.get(1);
		if (dir == DIRECTION.LEFT)
			anisprites = curAni.get(2);
		if (dir == DIRECTION.RIGHT)
			anisprites = curAni.get(3);

		anisprites.update();

		if (state == STATE.STAND) {
			anisprites.setFrame(0);
		}
	}
	
	public void collisionSignal() {
			
	}
	
	public void attack() {
		if(atSignalFrequency <=0 && state!=STATE.ATTACK) {
			attackSignal();
			atSignalFrequency=defaultAtSignalFrequency;}
		if(atSignal.getTarget()!=null) 
			 if(distance(atSignal.getTarget())<punchrange) {
				range=punchrange;
				attackFrame=2;
				damage=punchdamage;
				if(state!=STATE.ATTACK)
					state=STATE.ATTACK;
				if (state == STATE.ATTACK) {
					if (curAni==punch && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
						if (dir == DIRECTION.UP)
							level.add(new AtProjectile(x, y, 0, -1, this));
						if (dir == DIRECTION.DOWN)
							level.add(new AtProjectile(x, y, 0, 1, this));
						if (dir == DIRECTION.LEFT)
							level.add(new AtProjectile(x, y, -1, 0, this));
						if (dir == DIRECTION.RIGHT)
							level.add(new AtProjectile(x, y, 1, 0, this));
						rateOfFire = defaultFireRate;
					}
					if(anisprites.getFrame()==anisprites.getLength() - 1) {
						anisprites.setFrame(0);
						state=STATE.STAND;
					}
				}
			}else if(distance(atSignal.getTarget())>=punchrange && distance(atSignal.getTarget())<=shootrange) {
				range=shootrange;
				attackFrame=3;
				damage=shootdamage;
				if(state!=STATE.ATTACK)
					state=STATE.ATTACK;
				if (state == STATE.ATTACK) {
					if (curAni==attack && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
						if (dir == DIRECTION.UP)
							level.add(new AtProjectile(x, y, 0, -1, this, bulletforward, bulletup));
						if (dir == DIRECTION.DOWN)
							level.add(new AtProjectile(x, y, 0, 1, this, bulletforward, bulletup));
						if (dir == DIRECTION.LEFT)
							level.add(new AtProjectile(x, y, -1, 0, this, bulletforward, bulletup));
						if (dir == DIRECTION.RIGHT)
							level.add(new AtProjectile(x, y, 1, 0, this, bulletforward, bulletup));
						rateOfFire = defaultFireRate;
					}
					if(anisprites.getFrame()==anisprites.getLength() - 1) {
						anisprites.setFrame(0);
						state=STATE.STAND;
					}
				}
			}
	}
	
}