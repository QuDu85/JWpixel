package game.com.level.entity.mob.bot;

import java.util.ArrayList;
import java.util.List;

import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.Entity;
import game.com.level.entity.mob.Boss;
import game.com.level.entity.mob.Mob.DIRECTION;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.mob.player.Player;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;

public class TraceBoom extends EliteBot {

	private int existtime;
	private int radius;
	private Entity boss;
	private int width0, height0;
	private AniSprite bot_up = new AniSprite(16, 16, new SpriteSheet(16, 0, 16, 32, SpriteSheet.missile),
			PATTERN.VERTICAL);
	private AniSprite bot_down = new AniSprite(16, 16, new SpriteSheet(16, 32, 16, 32, SpriteSheet.missile),
			PATTERN.VERTICAL);
	private AniSprite bot_left = new AniSprite(16, 16, new SpriteSheet(0, 0, 16, 32, SpriteSheet.missile),
			PATTERN.VERTICAL);
	private AniSprite bot_right = new AniSprite(16, 16, new SpriteSheet(0, 32, 16, 32, SpriteSheet.missile),
			PATTERN.VERTICAL);

	public TraceBoom(int x, int y, int width, int height, Entity boss) {

		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.width0 = width;
		this.height = height;
		this.height0 = height;
		state = STATE.STAND;
		dir = DIRECTION.DOWN;

		move.add(bot_up);
		move.add(bot_down);
		move.add(bot_left);
		move.add(bot_right);

		speed = 2 * defaultspeed;
		maxhealth = 50;
		health = maxhealth;
		this.boss = boss;
		range = 400;
		damage = 60;
		curAni = move;
		existtime = 200;
		vision = 1000;
		radius = 20;
		interval = 30;
		anisprites = curAni.get(1);
	}

	public int getRadius() {
		return radius;
	}

	public void dirControl() {
		if (x0 < 0) {
			dir = DIRECTION.LEFT;
			width = width0;
			height = height0;
		} else if (x0 > 0) {
			dir = DIRECTION.RIGHT;
			width = width0;
			height = height0;
		} else if (y0 < 0) {
			dir = DIRECTION.UP;
			width = height0;
			height = width0;
		}
		if (y0 > 0) {
			dir = DIRECTION.DOWN;
			width = height0;
			height = width0;
		}
	}

	public void time() {
		super.time();
		existtime--;
	}

	public int getExisttime() {
		return existtime;
	}

	public void attack() {

	}

	public void move() {
		
	}
	
	public void collisionSignal() {

	}

	public void getAttack(AtProjectile p) {
		if (p.getsrcEntity() != boss) {
			state = STATE.GETATTACK;
			getAttackTime = defaultgetAttackTime;
			minusHealth(p.getDamage());
			if (health <= 0)
				explode();
			level.remove(p);
		}
	}

	public void explode() {
		SpawnParticle bang = new SpawnParticle(x, y, 0xab5261, 2, 30, level, EFFECT.RANDOM, 20);
		SpawnParticle bang2 = new SpawnParticle(x, y, 0xbca263, 2, 30, level, EFFECT.RANDOM, 20);
		List<Player> players = new ArrayList<>();
		players = level.detectPlayer(this, radius);
		if (!players.isEmpty())
			for (int i = 0; i < players.size(); i++)
				players.get(i).getAttack(this);
		level.remove(this);
	}

	public void explode(List<Player> players) {
		SpawnParticle bang = new SpawnParticle(x, y, 0xab5261, 2, 30, level, EFFECT.RANDOM, 20);
		SpawnParticle bang2 = new SpawnParticle(x, y, 0xbca263, 2, 30, level, EFFECT.RANDOM, 20);
		SpawnParticle bang3 = new SpawnParticle(x, y, 0xded6c1, 2, 15, level, EFFECT.EVAPORATE, 20);
		for (int i = 0; i < players.size(); i++)
			players.get(i).getAttack(this);
		level.remove(this);
	}

	public void update() {
		super.update();
		move();
		List<Player> players = new ArrayList<>();
		players = level.detectPlayer(this, radius);
		if (existtime < 0 || !players.isEmpty())
			explode(players);
	}

}
