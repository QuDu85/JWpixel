package game.com.level.entity.mob.player;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import game.com.Game;
import game.com.UI.UILabel;
import game.com.UI.UIManager;
import game.com.UI.UIPanel;
import game.com.UI.UIProgressBar;
import game.com.input.keyboard.Keyboard;
import game.com.input.mouse.Mouse;
import game.com.level.Particle;
import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.mob.Mob;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.mob.bot.TraceBoom;
import game.com.level.entity.projectile.CollisionProjectile;
import game.com.level.entity.projectile.DetectProjectile;
import game.com.level.entity.projectile.Projectile;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.entity.stat.Exp;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Player extends Mob {
	private final double defaultspeed = 2;
	private final int defaultFireRate = 10;
	private final int defaultgetAttackTime = 15;
	private final int punchspeed = 20;
	private int punchdamage = 40;
	private int shootdamage = 50;

	protected int getAttackTime = defaultgetAttackTime;
	private int rateOfFire;
	private boolean fatal = false;
	private int iFrame;
	private int modetime;
	private int attackFrame;
	private boolean bombed = false;

	private AniSprite player_up = new AniSprite(32, 32, new SpriteSheet(0, 0, 32, 128, SpriteSheet.playersheet),
			PATTERN.VERTICAL);
	private AniSprite player_down = new AniSprite(32, 32, new SpriteSheet(32, 0, 32, 128, SpriteSheet.playersheet),
			PATTERN.VERTICAL);
	private AniSprite player_left = new AniSprite(32, 32, new SpriteSheet(64, 0, 32, 128, SpriteSheet.playersheet),
			PATTERN.VERTICAL);
	private AniSprite player_right = new AniSprite(32, 32, new SpriteSheet(96, 0, 32, 128, SpriteSheet.playersheet),
			PATTERN.VERTICAL);
	List<AniSprite> move = new ArrayList<>();

	private AniSprite player_shoot_up = new AniSprite(32, 32, new SpriteSheet(0, 0, 32, 160, SpriteSheet.playershoot),
			PATTERN.VERTICAL);
	private AniSprite player_shoot_down = new AniSprite(32, 32,
			new SpriteSheet(32, 0, 32, 160, SpriteSheet.playershoot), PATTERN.VERTICAL);
	private AniSprite player_shoot_left = new AniSprite(32, 32,
			new SpriteSheet(64, 0, 32, 160, SpriteSheet.playershoot), PATTERN.VERTICAL);
	private AniSprite player_shoot_right = new AniSprite(32, 32,
			new SpriteSheet(96, 0, 32, 160, SpriteSheet.playershoot), PATTERN.VERTICAL);

	private AniSprite player_punch_up = new AniSprite(32, 32, new SpriteSheet(0, 0, 32, 160, SpriteSheet.playerpunch),
			PATTERN.VERTICAL);
	private AniSprite player_punch_down = new AniSprite(32, 32,
			new SpriteSheet(32, 0, 32, 160, SpriteSheet.playerpunch), PATTERN.VERTICAL);
	private AniSprite player_punch_left = new AniSprite(32, 32,
			new SpriteSheet(64, 0, 32, 160, SpriteSheet.playerpunch), PATTERN.VERTICAL);
	private AniSprite player_punch_right = new AniSprite(32, 32,
			new SpriteSheet(96, 0, 32, 160, SpriteSheet.playerpunch), PATTERN.VERTICAL);

	List<AniSprite> punch = new ArrayList<>();
	List<AniSprite> shoot = new ArrayList<>();

	List<AniSprite> curAni;

	private static final Sprite bulletup = new Sprite(16, 16, 16, 16, SpriteSheet.projectile);
	private static final Sprite bulletforward = new Sprite(16, 0, 16, 16, SpriteSheet.projectile);

	private AniSprite anisprites;
	private Keyboard key;
	private Mouse mouse;

	protected double xt, yt, zt;
	private int t, l;

	private int max_exp = 50;

	private int exp;
	private int lv;
	private int mode;

	private UIManager ui;
	private UIProgressBar health_bar;
	private UIProgressBar expBar;
	private UIProgressBar rateOfFireBar;
	private UIPanel panel;
	private UILabel label;

	public Player(int width, int height, Keyboard key, Mouse mouse) {
		this.width = width;
		this.height = height;
		this.key = key;
		this.mouse = mouse;

		speed = defaultspeed;
		maxhealth = 300;
		health = maxhealth;
		state = STATE.STAND;
		mode = 0;
		range = 30;
		damage = punchdamage;
		rateOfFire = punchspeed;
		exp = 0;
		lv = 1;
		attackFrame = 3;

		move.add(player_up);
		move.add(player_down);
		move.add(player_left);
		move.add(player_right);

		shoot.add(player_shoot_up);
		shoot.add(player_shoot_down);
		shoot.add(player_shoot_left);
		shoot.add(player_shoot_right);

		punch.add(player_punch_up);
		punch.add(player_punch_down);
		punch.add(player_punch_left);
		punch.add(player_punch_right);

		loadUI();

		curAni = move;
		anisprites = curAni.get(1);
	}

	public void loadUI() {
		ui = Game.getUI();

		panel = new UIPanel("playerUI", 0, 0, 80, 50, new Color(0xaa1f1f1f, true));
		ui.add(panel);
		label = new UILabel(4, 10, new Color(0xaaffffff, true), new Font("Futura", Font.PLAIN, 20), "Snpip");
		panel.add(label);
		health_bar = new UIProgressBar(2, 15, 70, 6, new Color(0xddc7273e, true));
		health_bar.setSpeed(0.016667);
		panel.add(health_bar);
		rateOfFireBar = new UIProgressBar(2, 22, 70, 6, new Color(0xdddf9444, true));
		panel.add(rateOfFireBar);
		expBar = new UIProgressBar(2, 29, 70, 6, new Color(0xdd981793, true));
		expBar.setSpeed(0.016667);
		panel.add(expBar);

	}

	public void uiUpdate() {

		health_bar.setProgress((double) health / maxhealth);
		health_bar.setText(2, 5, "HP : " + health + " / " + maxhealth, "Futura");
		expBar.setProgress((double) exp / max_exp);
		expBar.setText(2, 5, "LEVEL : " + lv, "Futura");
		if (mode == 0)
			rateOfFireBar.setProgress((double) rateOfFire / punchspeed);
		else
			rateOfFireBar.setProgress((double) rateOfFire / defaultFireRate);

	}

	public void collecting() {
		List<Particle> list = this.level.detectParticle(this);
		if (!list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i) instanceof Exp) {
					Exp p = (Exp) list.get(i);
					exp += p.getAmount();
					level.remove(p);
				}
			}
		}
	}

	public void levelControl() {
		if (exp > max_exp) {
			lv++;
			max_exp *= 2;
			exp = 0;
			punchdamage += punchdamage * lv / 5;
			shootdamage += shootdamage * lv / 5;
			maxhealth=maxhealth*4/3;
			health=maxhealth;
		}
	}

	public void modeControl() {
		if (lv == 1)
			return;
		if (mode == 0) {
			range = 30;
			damage = punchdamage;
		} else {
			range = 400;
			damage = shootdamage;
		}
		if ((mouse.getButton() == MouseEvent.BUTTON3 || key.changemode) && modetime > 10) {
			mode = (mode + 1) % 2;
			modetime = 0;
			if (mode == 0) {
				rateOfFire = punchspeed;
			} else {
				rateOfFire = defaultFireRate;
			}
		}
	}

	public void dirControl() {
		double xs = x - screen.getX_ofs();
		double ys = y - screen.getY_ofs();
		double tan = (double) (Game.height - ys) / (Game.width - xs);
		double x0 = mouse.getX() - xs * Game.scale;
		double y0 = mouse.getY() - ys * Game.scale;
		if (state != STATE.ATTACK && state != STATE.COLLISION && state != STATE.GETATTACK) {
			if (x0 * tan > y0 && (-x0 * tan) > y0)
				dir = DIRECTION.UP;
			if (x0 * tan < y0 && (-x0 * tan) < y0)
				dir = DIRECTION.DOWN;
			if (x0 * tan < y0 && (-x0 * tan) > y0)
				dir = DIRECTION.LEFT;
			if (x0 * tan > y0 && (-x0 * tan) < y0)
				dir = DIRECTION.RIGHT;
		}
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public void aniControl() {
		if (state == STATE.WALKING)
			curAni = move;
		else if (state == STATE.ATTACK) {
			if (mode == 0)
				curAni = punch;
			else
				curAni = shoot;
		} else if (state == STATE.STAND) {
			curAni = move;

		}
		if (dir == DIRECTION.UP)
			anisprites = curAni.get(0);
		if (dir == DIRECTION.DOWN)
			anisprites = curAni.get(1);
		if (dir == DIRECTION.LEFT)
			anisprites = curAni.get(2);
		if (dir == DIRECTION.RIGHT)
			anisprites = curAni.get(3);

		anisprites.update();

		if (state == STATE.STAND) {
			anisprites.setFrame(0);
		}

		for (int i = 0; i < shoot.size(); i++) {
			shoot.get(i).setFPS(200 / defaultFireRate);
			punch.get(i).setFPS(200 / punchspeed);

		}
	}

	public void shooting() {
		if ((key.attack || mouse.getButton() == 1) && state != STATE.ATTACK)
			state = STATE.ATTACK;
		if (state == STATE.ATTACK) {
			System.out.println(damage);
			if (curAni == punch && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
				if (mode == 0) {
					if (dir == DIRECTION.UP) {
						level.add(new AtProjectile(x, y, 0, -1, this));
						l = range;
					} else if (dir == DIRECTION.DOWN) {
						level.add(new AtProjectile(x, y, 0, 1, this));
						l = -range;
					} else if (dir == DIRECTION.LEFT) {
						level.add(new AtProjectile(x, y, -1, 0, this));
						t = range - width / 2;
					} else if (dir == DIRECTION.RIGHT) {
						level.add(new AtProjectile(x, y, 1, 0, this));
						t = -range + width / 2;
					}
					rateOfFire = punchspeed;
				}
			} else if (curAni == shoot && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
				if (mode == 1) {
					if (dir == DIRECTION.UP)
						level.add(new AtProjectile(x, y, 0, -1, this, bulletforward, bulletup));
					else if (dir == DIRECTION.DOWN)
						level.add(new AtProjectile(x, y, 0, 1, this, bulletforward, bulletup));
					else if (dir == DIRECTION.LEFT)
						level.add(new AtProjectile(x, y, -1, 0, this, bulletforward, bulletup));
					else if (dir == DIRECTION.RIGHT)
						level.add(new AtProjectile(x, y, 1, 0, this, bulletforward, bulletup));
					rateOfFire = defaultFireRate;
				}
			}
		} else {
			t = 0;
			l = 0;
		}
		if (anisprites.getFrame() == anisprites.getLength() - 1) {
			anisprites.setFrame(0);
			state = STATE.STAND;
		}
	}

	public void moving() {
		x0 = 0;
		y0 = 0;
		speed = defaultspeed;
		if (key.run)
			speed = defaultspeed * 2;
		if (key.up) {
			y0 -= speed;
		} else if (key.down) {
			y0 += speed;
		} else if (key.left) {
			x0 -= speed;
		} else if (key.right) {
			x0 += speed;
		}
		move(x0, y0);

		anisprites.setFPS(speed * 2);
	}

	public void getAttack(AtProjectile p) {
		if (p.getsrcEntity() != this && iFrame <= 0) {
			state = STATE.GETATTACK;
			getAttackTime = defaultgetAttackTime;
			minusHealth(p.getDamage());
			if (health <= 0)
				fatal = true;
			x0 = p.getXd() * p.getSpeed();
			y0 = p.getYd() * p.getSpeed();
			z0 = p.getSpeed() / 2;
			xt = Math.abs(x0);
			yt = Math.abs(y0);
			zt = Math.abs(z0);
			level.remove(p);
		}
	}

	public void getAttack(TraceBoom bomb) {
		if (iFrame <= 0) {
			state = STATE.GETATTACK;
			getAttackTime = defaultgetAttackTime;
			minusHealth(bomb.getDamage());
			level.remove(bomb);
			x0 = sign(x - bomb.getX()) * bomb.getSpeed();
			y0 = sign(y - bomb.getY()) * bomb.getSpeed();
			z0 = bomb.getSpeed() / 2;
			xt = Math.abs(x0);
			yt = Math.abs(y0);
			zt = Math.abs(z0);
			bombed = true;
		}
	}

	public void getSignal() {
		List<Projectile> list = this.level.detectProjectile(this);
		if (!list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				Projectile p = list.get(i);
				if (list.get(i) instanceof AtProjectile) {
					getAttack((AtProjectile) p);
				} else if (p instanceof DetectProjectile) {
					((DetectProjectile) p).setTarget(this);
				}
			}

		}
	}

	public CollisionProjectile collisionEntity() {
		List<Projectile> list = level.detectProjectile(this);
		if (!list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i) instanceof CollisionProjectile)
					return (CollisionProjectile) list.get(i);
			}
		}
		return null;

	}

	public void getAttackEffect() {
		if (getAttackTime <= 0 && (state == STATE.GETATTACK || state == STATE.COLLISION)) {
			state = STATE.STAND;
			bombed = false;
		}

		if (state == STATE.GETATTACK || state == STATE.COLLISION) {
			if (!fatal) {
				if (!bombed) {
					if (state == STATE.GETATTACK) {
						SpawnParticle sp = new SpawnParticle(x, y, 0xc62020, 2, 10, level, EFFECT.FALLING, 20);
					} else {
						SpawnParticle shock = new SpawnParticle(x, y, 0x4b9abf, 2, 10, level, EFFECT.RANDOM, 20);
					}
				}
				iFrame = 50;
			}
			x0 -= sign(x0) * xt / defaultgetAttackTime;
			y0 -= sign(y0) * yt / defaultgetAttackTime;
			z += z0;
			z0 -= zt * 2 / defaultgetAttackTime;
			move(x0, y0);

		} else
			z = 0;

	}

	public void time() {
		rateOfFire--;
		if (rateOfFire < -5000)
			rateOfFire = -1;
		getAttackTime--;
		if (getAttackTime < -5000)
			getAttackTime = -1;
		iFrame--;
		if (iFrame < -5000)
			iFrame = -1;
		time++;
		modetime++;
	}

	public void collisionBot() {
		if (collisionEntity() != null && iFrame <= 0) {
			CollisionProjectile p = collisionEntity();
			state = STATE.COLLISION;
			getAttackTime = defaultgetAttackTime;
			x0 = p.getXd() * p.getSpeed();
			y0 = p.getYd() * p.getSpeed();
			z0 = p.getSpeed() / 2;
			xt = Math.abs(x0);
			yt = Math.abs(y0);
			zt = Math.abs(z0);
			minusHealth(p.getDamage());
			if (health <= 0)
				fatal = true;
		}
	}

	public void update() {
		time();
		dirControl();
		aniControl();
		getSignal();
		levelControl();
		modeControl();
		collecting();
		if (state != STATE.GETATTACK && state != STATE.COLLISION) {
			if (state != STATE.ATTACK)
				moving();
			shooting();
		}
		collisionBot();
		getAttackEffect();
		if (health <= 0) {
			fatal = false;
			ui.changePanel("gameover");
			level.remove(this);
			sys.setGameover(true);
		}
		if (level.isDog(this)) {
			Game.setVictory(true);
			Game.setIngame(false);
		}
		System.out.println(ui.getCurName());
		uiUpdate();
	}

	public void render(Screen screen) {
		this.sprite = anisprites.frame();
		if (iFrame <= 0)
			screen.renderEntity((int) (x - t - sprite.getWidth() / 2), (int) (y - l - z - sprite.getHeight() / 2),
					this);
		else if (time % 3 == 0)
			screen.renderEntity((int) (x - t - sprite.getWidth() / 2), (int) (y - l - z - sprite.getHeight() / 2),
					this);
	}
}
