package game.com.level.entity.mob.bot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import game.com.level.entity.mob.Mob.DIRECTION;
import game.com.level.entity.mob.player.Player;
import game.com.util.Node;
import game.com.util.Vec;

public class EliteBot extends Minion {

	List<Vec> tracePath = new ArrayList<>();
	protected int traceTime = 0;
	protected int vision = 200;
	protected int interval = 30;

	public EliteBot() {

	}

	public void moving() {
		x0 = 0;
		y0 = 0;
		List<Player> list = level.detectPlayer(this, vision);
		if (!list.isEmpty()) {
			if (traceTime % interval == 0) {
				if (tracePath != null)
					tracePath.clear();
				tracePath = trace(list.get(0));
			}
			if (tracePath == null)
				return;
			
			if (!tracePath.isEmpty()) {
				Vec target = tracePath.get(tracePath.size() - 1);
				if(target.distance(new Vec(x,y))<1) {
					tracePath.remove(target);
				}
				if (x - target.getX() > 1) {
					x0 -= speed;
					dir = DIRECTION.LEFT;
				} else if (target.getX() - x > 1) {
					x0 += speed;
					dir = DIRECTION.RIGHT;
				} else if (y - target.getY() > 1) {
					y0 -= speed;
					dir = DIRECTION.UP;
				} else if (target.getY() - y > 1) {
					y0 += speed;
					dir = DIRECTION.DOWN;
				} 
				move(x0, y0);
			}
		}

	}

	public List<Vec> trace(Player p) {
		List<Vec> l = new ArrayList<>();
		Vec start = new Vec(x, y);
		Vec finish = new Vec(p.getX(), p.getY());
		double dis = start.distance(finish);

		Node begin = new Node(start, null, 0, dis);
		List<Node> set = new ArrayList<>();
		List<Node> visited = new ArrayList<>();
		set.add(begin);

		Node tmp = set.get(0);
		while (!set.isEmpty()) {
			Collections.sort(set, compareNode);
			Node curNode = set.get(0);
			for (int i = 0; i < set.size(); i++) {
				if (set.get(i).getParent() == null)
					continue;
				if (set.get(i).getParent().equals(tmp)) {
					curNode = set.get(i);
					break;
				}
			}
			tmp = curNode;
			if (curNode.getTotal() > vision) {
				set.clear();
				break;
			}

			if (cmp(curNode, finish)) {
				while (curNode.getParent() != null) {
					l.add(curNode.getV());
					curNode = curNode.getParent();
				}
				set.clear();
				visited.clear();

				return l;
			}

			set.remove(curNode);
			visited.add(curNode);

			for (int i = 0; i < 9; i++) {
				if (i % 2 == 0)
					continue;
				double xi = ((i % 3) - 1) * speed * 8;
				double yi = ((i / 3) - 1) * speed * 8;

				double x0 = curNode.getV().getX();
				double y0 = curNode.getV().getY();

				if (collision(x0, y0, xi, yi, width, height))
					continue;

				Vec newVec = new Vec(x0 + xi, y0 + yi);
				double newPath = curNode.getPath() + Math.abs(xi + yi)*(xi==0?0.5:1);
				double newDis = newVec.distance(finish);
				Node newNode = new Node(newVec, curNode, newPath, newDis);

				if (findNode(visited, newNode))
					continue;
				if (!findNode(set, newNode))
					set.add(newNode);
			}
		}
		visited.clear();
		return null;
	}

	public boolean findNode(List<Node> l, Node n) {
		for (int i = 0; i < l.size(); i++) {
			if (l.get(i).equals(n))
				return true;
		}
		return false;
	}

	public boolean cmp(Node n, Vec v) {
		if (n.getV().distance(v) < 16)
			return true;
		else
			return false;
	}

	Comparator<Node> compareNode = new Comparator<>() {
		public int compare(Node o1, Node o2) {
			if (o1.getTotal() > o2.getTotal())
				return 1;
			else if (o1.getTotal() < o2.getTotal())
				return -1;
			return 0;
		}
	};

	public void time() {
		time = (time + 1) % 240;
		getAttackTime--;
		if (getAttackTime < -1000)
			getAttackTime = -1;
		atSignalFrequency--;
		if (atSignalFrequency < -1000)
			atSignalFrequency = -1;
		rateOfFire--;
		if (rateOfFire < -1000)
			rateOfFire = -1;
		traceTime++;
	}

	public void update() {
		aniControl();
		getSignal();

		if (state != STATE.GETATTACK) {
			if (state != STATE.ATTACK)
				moving();
			attack();
		}
		collisionSignal();
		getAttackEffect();
		time();
	}
}
