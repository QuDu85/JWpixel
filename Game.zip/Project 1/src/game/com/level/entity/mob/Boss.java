package game.com.level.entity.mob;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import game.com.Game;
import game.com.UI.UIManager;
import game.com.UI.UIPanel;
import game.com.UI.UIProgressBar;
import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.mob.bot.Minion;
import game.com.level.entity.mob.bot.TraceBoom;
import game.com.level.entity.mob.player.Player;
import game.com.level.entity.projectile.CollisionProjectile;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Boss extends Minion {

	private final int defaultLazerTime = 200;
	private final int defaultLazerLength = 50;

	private final int defaulttraceBoomTime = 400;
	private final int defaultStunTime = 200;

	private int lazerCoolDown = defaultLazerTime;
	private int lazerLength = defaultLazerLength;

	private boolean lazerAvailable = false;
	private boolean getAttack = false;
	
	private boolean traceBoomAvailable = false;
	private int traceBoomCoolDown = defaulttraceBoomTime;
	private int stunTime = defaultStunTime;
	private UIManager ui;
	private UIPanel panel;
	private UIProgressBar healthbar;

	private AniSprite bullet_up = new AniSprite(16, 16, new SpriteSheet(0, 0, 16, 64, SpriteSheet.rangedprojectile),
			PATTERN.VERTICAL);
	private AniSprite bullet_forward = new AniSprite(16, 16,
			new SpriteSheet(16, 0, 16, 64, SpriteSheet.rangedprojectile), PATTERN.VERTICAL);

	protected AniSprite boss = new AniSprite(64, 128, SpriteSheet.boss, PATTERN.VERTICAL);
	protected AniSprite boss_at = new AniSprite(64, 128, SpriteSheet.bossattack, PATTERN.VERTICAL);
	protected AniSprite boss_stagger = new AniSprite(64, 128, SpriteSheet.bossstagger, PATTERN.VERTICAL);
	protected AniSprite aniSprite;

	public Boss(int x, int y, int width, int height) {
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;

		this.maxhealth = 10000;
		this.health = maxhealth;
		state = STATE.STAND;
		damage=80;

		dir = DIRECTION.LEFT;

		aniSprite = boss;
		this.sprite = aniSprite.getFrame(1);
		aniSprite.setFPS(3);
		this.speed = 0.5;
		collisionDamage=50;
//		inVision = new DetectProjectTile(x,y,1,0,this);
//		inAttackRange = new DetectProjectTile();

//		detectTime = defaultdetectTime * 4;

		loadUI();
	}

	public void staggerState() {
		if (state == STATE.STAGGER) {
			aniSprite = boss_stagger;
			stunTime--;
			if (stunTime < 0) {
				stunTime = defaultStunTime;
				state = STATE.STAND;
				aniSprite = boss;
			}
		}
	}

	public boolean detecPlayer() {
		List<Player> players = new ArrayList<>();
		players = this.level.detectPlayer(this, Game.width*3/2);
		if (!players.isEmpty())
			return true;
		return false;
	}

	public void loadUI() {
		ui = Game.getUI();
		panel = new UIPanel("bossPanel", 50, 130, 200, 10, new Color(0xffffff));
		ui.add(panel);
		ui.setTemp(panel);
		healthbar = new UIProgressBar(0, 0, 200, 10, new Color(0xddf11b35, true));
		panel.add(healthbar);
	}

	public void updateUI() {
		healthbar.setProgress((double) health / maxhealth);

	}

	public void getAttack(AtProjectile p) {
		if (p.getsrcEntity() != this) {
//			if(state!=STATE.STAGGER)
			getAttack=true;
			getAttackTime = defaultgetAttackTime;
			minusHealth(p.getDamage());
			x0 = p.getXd() * p.getSpeed();
			y0 = p.getYd() * p.getSpeed();
			z0 = p.getSpeed() / 2;
			xt = Math.abs(x0);
			yt = Math.abs(y0);
			zt = Math.abs(z0);
			if (health <= 0) {
				level.remove(this);
				SpawnParticle sp = new SpawnParticle(x, y, 2, 50, level, EFFECT.RANDOM, 200, totalexp / 50);
			}

			level.remove(p);
		}
	}

	public void getAttackEffect() {
		if (getAttackTime <= 0 && getAttack) {
			state = STATE.STAND;
			getAttack=false;
		}
		if (getAttack) {
			SpawnParticle sp = new SpawnParticle(x, y, 0x2f7aeb, 2, 10, level, EFFECT.FALLING, 20);
			SpawnParticle sp2 = new SpawnParticle(x, y, 0xbcc6d4, 2, 10, level, EFFECT.FALLING, 20);
		}
	}

	public void update() {
		time();

		aniSprite.update();

		sendCollision();

		getSignal();

		updateUI();
		staggerState();
//		System.out.println(state);

		if (detecPlayer()) {
			if (state != STATE.STAGGER) {
				if (state != STATE.GETATTACK) {
					moving();
				}
				attack();
			}
			
			ui.setTempVisible(true);
		}
		else 
			ui.setTempVisible(false);
		getAttackEffect();

		this.sprite = aniSprite.frame();

	}

	public void moving() {
		x0 = 0;
		y0 = 0;
		if (time < 75) {
			y0 += speed;
		} else if (time < 150)
			y0 -= speed;
		else
			time = 0;

		move(x0, y0);

	}

	public void attack() {
		if (lazerAvailable) {
			state = STATE.ATTACK;
			lazer();
			return;
		} else if (traceBoomAvailable) {
			if (state != STATE.ATTACK)
				aniSprite = boss_at;
			state = STATE.ATTACK;
			traceBoom();
		}
	}

	public void traceBoom() {

		if (aniSprite.getFrame() == 3) {
			int xi = (int) (x / 16);
			int yi = (int) (y / 16);
			level.add(new TraceBoom((int) xi, (int) yi + 1, 16, 8, this));
			level.add(new TraceBoom((int) xi + 1, (int) yi + 1, 16, 8, this));
			level.add(new TraceBoom((int) xi - 1, (int) yi + 1, 16, 8, this));
			level.add(new TraceBoom((int) xi, (int) yi - 1, 16, 8, this));
			state = STATE.STAGGER;
			traceBoomAvailable = false;
			traceBoomCoolDown = 200;
			aniSprite.setFrame(0);
			aniSprite = boss;
		}

//		if(aniSprite.getFrame() == aniSprite.getLength() - 1) {
//			state = STATE.STAGGER;
//			traceBoomAvailable = false;
//			traceBoomCoolDown = 200;
//			aniSprite.setFrame(0);
//			aniSprite = boss;
//		}
	}

	public void lazer() {
		if (lazerLength > 0) {
			level.add(new AtProjectile(x, y - 30, -1, 0, this, bullet_up, bullet_forward));
		}
		lazerLength--;
		if (lazerLength < 0) {
			lazerLength = defaultLazerLength;
			lazerAvailable = false;
			lazerCoolDown = defaultLazerTime;
			state = STATE.STAND;
		}
	}

	public void sendCollision() {
		int dia = (int) Math.sqrt(width * width + height * height) / 2;

		level.add(new CollisionProjectile(x, y, 1, 0, width / 2, this));
		level.add(new CollisionProjectile(x, y, -1, 0, width / 2, this));
		level.add(new CollisionProjectile(x, y, 0, 1, height / 2, this));
		level.add(new CollisionProjectile(x, y, 0, -1, height / 2, this));

		level.add(new CollisionProjectile(x, y, 1, 1, dia, this));
		level.add(new CollisionProjectile(x, y, -1, 1, dia, this));
		level.add(new CollisionProjectile(x, y, -1, -1, dia, this));
		level.add(new CollisionProjectile(x, y, 1, -1, dia, this));
	}

	public void time() {
		super.time();

		lazerCoolDown--;
		if (lazerCoolDown < 0) {
			lazerAvailable = true;
		}
		traceBoomCoolDown--;
		if (traceBoomCoolDown < 0) {
			traceBoomAvailable = true;
		}

	}

	public void render(Screen screen) {
		this.sprite = aniSprite.frame();
		screen.renderEntity((int) x - this.sprite.getWidth() / 2, (int) y - this.sprite.getHeight() / 2, this);
	}

}
