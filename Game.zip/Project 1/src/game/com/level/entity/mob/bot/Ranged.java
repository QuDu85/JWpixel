package game.com.level.entity.mob.bot;

import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.projectile.atprojectile.AtProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.levelsys.LevelSys.MODE;
import game.com.screen.Screen;

public class Ranged extends Minion{
	private AniSprite bullet_up = new AniSprite(16,16,new SpriteSheet(0,0,16,64,SpriteSheet.rangedprojectile), PATTERN.VERTICAL);
	private AniSprite bullet_forward = new AniSprite(16,16,new SpriteSheet(16,0,16,64,SpriteSheet.rangedprojectile), PATTERN.VERTICAL);

	public Ranged(int x, int y, int width, int height, PATTERN pattern, MODE mode) {
		bot_up = new AniSprite(32,64,new SpriteSheet(0,0,32,320, SpriteSheet.ranged), PATTERN.VERTICAL);
		bot_down = new AniSprite(32,64,new SpriteSheet(32,0,32,320, SpriteSheet.ranged), PATTERN.VERTICAL);
		bot_left = new AniSprite(32,64,new SpriteSheet(64,0,32,320, SpriteSheet.ranged), PATTERN.VERTICAL);
		bot_right = new AniSprite(32,64,new SpriteSheet(96,0,32,320, SpriteSheet.ranged), PATTERN.VERTICAL);
		
		bot_attack_up = new AniSprite(64, 64,
				new SpriteSheet(0, 0, 64, 320, SpriteSheet.rangedattack), PATTERN.VERTICAL);
		bot_attack_down = new AniSprite(64, 64,
				new SpriteSheet(64, 0, 64, 320, SpriteSheet.rangedattack), PATTERN.VERTICAL);
		bot_attack_left = new AniSprite(64, 64,
				new SpriteSheet(128, 0, 64, 320, SpriteSheet.rangedattack), PATTERN.VERTICAL);
		bot_attack_right = new AniSprite(64, 64,
				new SpriteSheet(192, 0, 64, 320, SpriteSheet.rangedattack), PATTERN.VERTICAL);
		
		this.x=x<<4;
		this.y=y<<4;
		this.width=width;
		this.height=height;
		this.pattern=pattern;
		state = STATE.STAND;
		dir = DIRECTION.DOWN;
		attackFrame=4;
		
		move.add(bot_up);
		move.add(bot_down);
		move.add(bot_left);
		move.add(bot_right);
		
		attack.add(bot_attack_up);
		attack.add(bot_attack_down);
		attack.add(bot_attack_left);
		attack.add(bot_attack_right);

		for (int i = 0; i < attack.size(); i++) {
			attack.get(i).setFPS(300 / defaultFireRate);
		}
		
		collisionDamage=20;
		speed=defaultspeed;
		if(mode==MODE.HARD)
		maxhealth=200;
		else maxhealth=150;
		health=maxhealth;
		totalexp=100;
		curAni = move;
		anisprites= curAni.get(1);
	}
	
	public void attack() {
		if(atSignalFrequency <=0 && state!=STATE.ATTACK) {
			attackSignal();
			atSignalFrequency=defaultAtSignalFrequency;}
		if(atSignal.getTarget()!=null && distance(atSignal.getTarget())<=range) 
			if(state!=STATE.ATTACK)
				state=STATE.ATTACK;
			if (state == STATE.ATTACK) {
				if (curAni==attack && anisprites.getFrame() == attackFrame && rateOfFire < 0) {
					if (dir == DIRECTION.UP)
						level.add(new AtProjectile(x, y, 0, -1, this, bullet_up, bullet_forward));
					if (dir == DIRECTION.DOWN)
						level.add(new AtProjectile(x, y, 0, 1, this, bullet_up, bullet_forward));
					if (dir == DIRECTION.LEFT)
						level.add(new AtProjectile(x, y, -1, 0, this, bullet_up, bullet_forward));
					if (dir == DIRECTION.RIGHT)
						level.add(new AtProjectile(x, y, 1, 0, this, bullet_up, bullet_forward));
					rateOfFire = defaultFireRate;
				}
				if(anisprites.getFrame()==anisprites.getLength() - 1) {
					anisprites.setFrame(0);
					state=STATE.STAND;
				}
			}
	}
	public boolean collision(double x, double y, double x0, double y0, int width, int height) {
		int xt;
		int yt= ((int) (y +y0 +height)) >>4;
		for(int i=0;i<2;i++) {
			xt=((int)(x+x0-width/2+i*width))>>4;
			if(level.getTile(xt, yt).isSolid()) return true;
		}
		return false;
	}
	
	public void render(Screen screen) {
		this.sprite=anisprites.frame();
		screen.renderEntity((int)(x-sprite.getWidth()/2),(int)(y-z-16),this);

	}
	
}
