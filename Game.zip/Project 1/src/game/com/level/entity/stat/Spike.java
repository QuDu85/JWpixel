package game.com.level.entity.stat;

import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.projectile.CollisionProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Spike extends Trap {
	private PATTERN pattern;

	public Spike(int x, int y, int width, int height, PATTERN pattern) {
		collisionDamage = 50;
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;
		this.pattern = pattern;
		if (pattern == PATTERN.VERTICAL)
			animation = new AniSprite(16, 16, new SpriteSheet(0, 112, 64, 16, SpriteSheet.walltile2),
					PATTERN.HORIZONTAL);
		else
			animation = new AniSprite(16, 16, new SpriteSheet(64, 112, 64, 16, SpriteSheet.walltile2),
					PATTERN.HORIZONTAL);
		animation.setFrame(0);
	}

	public void collisionSignal() {
		level.add(new CollisionProjectile(x + width / 2, y + height / 2, 1, 0, width / 2, this));
		level.add(new CollisionProjectile(x + width / 2, y + height / 2, -1, 0, width / 2, this));
		level.add(new CollisionProjectile(x + width / 2, y + height / 2, 0, -1, height / 2, this));
		level.add(new CollisionProjectile(x + width / 2, y + height / 2, 0, 1, height / 2, this));
	}

	public void render(Screen screen) {
		this.sprite = animation.frame();
		screen.renderEntity((int) (x), (int) (y), this);

	}

}
