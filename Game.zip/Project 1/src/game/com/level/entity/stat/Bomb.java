package game.com.level.entity.stat;

import java.util.List;

import game.com.level.Particle.EFFECT;
import game.com.level.SpawnParticle;
import game.com.level.entity.Entity;
import game.com.level.entity.projectile.Projectile;
import game.com.level.entity.projectile.atprojectile.AtProjectile;

public class Bomb extends Entity{
	
	
	
	public void explode() {
		SpawnParticle sp = new SpawnParticle(x,y,0xc81f1f,2,50,level,EFFECT.RANDOM,50);
	}
	
	public void getSignal() {
		List <Projectile> list = this.level.detectProjectile(this);
		if(!list.isEmpty()) {
			for(int i=0; i<list.size();i++) {
				Projectile p = list.get(i);
				if(list.get(i) instanceof AtProjectile) {
					explode();
					System.out.println("HEY!!");
				}
			}
		}
	}
	
	public void update() {
		getSignal();
	}
	
	public void render() {
		
	}
	
}
