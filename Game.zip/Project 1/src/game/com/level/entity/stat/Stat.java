package game.com.level.entity.stat;

import game.com.level.entity.Entity;

public class Stat extends Entity{

}
