package game.com.level.entity.stat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Bubble extends Stat {
	private AniSprite animation1 = new AniSprite(16, 16, new SpriteSheet(0, 0, 16, 64, SpriteSheet.bubble),
			PATTERN.VERTICAL);
	private AniSprite animation2 = new AniSprite(16, 16, new SpriteSheet(16, 0, 16, 64, SpriteSheet.bubble),
			PATTERN.VERTICAL);
	private AniSprite animation;
	List<AniSprite> anisprite = new ArrayList<>();
	private Random random = new Random();

	public Bubble(int x, int y, int width, int height) {
		collisionDamage = 50;
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;
		anisprite.add(animation1);
		anisprite.add(animation2);
		animation = anisprite.get(random.nextInt(2));
		animation.setFrame(0);
	}

	public void update() {
		animation.update();
		if (animation.getFrame() == animation.getLength())
			animation = anisprite.get(random.nextInt(2));
	}

	public void render(Screen screen) {
		this.sprite = animation.frame();
		screen.renderEntity((int) (x - sprite.getWidth() / 2), (int) (y - sprite.getHeight() / 2), this);

	}
}
