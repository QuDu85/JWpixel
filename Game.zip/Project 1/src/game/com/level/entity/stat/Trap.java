package game.com.level.entity.stat;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.projectile.CollisionProjectile;
import game.com.level.spritesheet.AniSprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Trap extends Stat {

	protected AniSprite animation;

	public Trap(int x, int y, int width, int height) {
		collisionDamage = 50;
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;
		animation = new AniSprite(16, 16, SpriteSheet.trap, PATTERN.VERTICAL);
		animation.setFrame(0);
	}

	public Trap() {

	}

	public void collisionSignal() {
		level.add(new CollisionProjectile(x, y, 1, 0, width / 2, this));
		level.add(new CollisionProjectile(x, y, -1, 0, width / 2, this));
		level.add(new CollisionProjectile(x, y, 0, -1, width / 2, this));
		level.add(new CollisionProjectile(x, y, 0, 1, width / 2, this));
	}

	public void update() {
		collisionSignal();
		animation.update();
	}

	public void render(Screen screen) {
		this.sprite = animation.frame();
		screen.renderEntity((int) (x - sprite.getWidth() / 2), (int) (y - sprite.getHeight() / 2), this);

	}
}
