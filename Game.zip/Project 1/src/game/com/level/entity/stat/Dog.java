package game.com.level.entity.stat;

import game.com.level.entity.Entity;
import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Dog extends Stat{

	public Dog() {
		super();
		
	}

	public Dog(int x, int y, int width, int height) {
		this.x = x << 4;
		this.y = y << 4;
		this.width = width;
		this.height = height;
		this.sprite= new Sprite(0,0,32,32, SpriteSheet.dog);
		
	}
	
	public void render(Screen screen) {
		screen.renderEntity((int) (x - sprite.getWidth() / 2), (int) (y - sprite.getHeight() / 2), this);

	}
	
}
