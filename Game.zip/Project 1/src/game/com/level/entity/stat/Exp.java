package game.com.level.entity.stat;

import game.com.level.Particle;

public class Exp extends Particle {
	private int amount;
	private static int color = 0x95e87c;

	public Exp() {

	}

	public Exp(double x, double y, int size, EFFECT effect, double time, int amount) {
		super(x, y, color, size, effect, time);
		this.amount = amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
