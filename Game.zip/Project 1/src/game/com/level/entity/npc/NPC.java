//package game.com.level.entity.npc;
//
//import game.com.level.entity.Entity;
//
//public class NPC extends Entity{
//	private String [] dialogues;
//	private int numOfDia;
//
//	public NPC() {
//
//	}
//	
//	public NPC(int numOfDia, ) {
//		
//	}
//}
