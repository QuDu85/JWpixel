package game.com.level.gate;

import game.com.level.Level;

public class Gate {
	public static int gateID1=0x000001;
	
	private int x,y;
	private int width,height;
	private Level srclevel;
	private Level desLevel;
	private int ID;
	
	public Gate(int code, int x, int y, int width,int height, Level src) {
		ID=code;
		this.x=x;
		this.y=y;
		this.width=width;
		this.height=height;
		this.srclevel=src;

	}

	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}
	public int getY() {
		return y;
	}

	public static int getGateID1() {
		return gateID1;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Level getSrclevel() {
		return srclevel;
	}

	public Level getDesLevel() {
		return desLevel;
	}

	public int getID() {
		return ID;
	}
	
}
