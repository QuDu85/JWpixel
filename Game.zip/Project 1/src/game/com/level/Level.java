package game.com.level;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import game.com.level.entity.Entity;
import game.com.level.entity.mob.Boss;
import game.com.level.entity.mob.bot.Hunter;
import game.com.level.entity.mob.bot.Minion.PATTERN;
import game.com.level.entity.mob.bot.Ranged;
import game.com.level.entity.mob.bot.Tank;
import game.com.level.entity.mob.player.Player;
import game.com.level.entity.projectile.Projectile;
import game.com.level.entity.stat.Bubble;
import game.com.level.entity.stat.Dog;
import game.com.level.entity.stat.Spike;
import game.com.level.entity.stat.Trap;
import game.com.level.gate.Gate;
import game.com.level.tile.Tile;
import game.com.levelsys.LevelSys.MODE;
import game.com.screen.Screen;

public class Level {
	private int width;
	private int height;
	private int[] tilepixels;
	private int[] entitypixels;

	private List<Player> players = new ArrayList<Player>();
	private List<Entity> entities = new ArrayList<Entity>();
	private List<Gate> gates = new ArrayList<>();
	private List<Particle> particles = new ArrayList<>();

	public int getWidth() {
		return width << 4;
	}

	public int getHeight() {
		return height << 4;
	}

	private List<Projectile> projectiles = new ArrayList<>();

	public Level(String path1, String path2) {
		loadTile(path1);
		loadEntity(path2);
	}

	public List<Player> detectPlayer(Entity e, int range) {
		List<Player> list = new ArrayList<>();
		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			double dx = e.getX() - p.getX();
			double dy = e.getY() - p.getY();
			if (Math.sqrt(dx * dx + dy * dy) < range)
				list.add(p);
		}
		return list;
	}

	public List<Particle> detectParticle(Entity e) {
		List<Particle> list = new ArrayList<>();
		for (int i = 0; i < particles.size(); i++) {
			Particle p = particles.get(i);
			double dx = e.getX() - p.getX();
			double dy = e.getY() - p.getY();
			double da = dx / (e.getWidth() / 2);
			double db = dy / (e.getHeight() / 2);

			if ((da * da + db * db) < 1)
				list.add(p);
		}
		return list;
	}

	public List<Projectile> detectProjectile(Entity e) {
		List<Projectile> list = new ArrayList<>();
		for (int i = 0; i < projectiles.size(); i++) {
			Projectile p = projectiles.get(i);
			double dx = e.getX() - p.getX();
			double dy = e.getY() - p.getY();
			double da = dx / (e.getWidth() / 2);
			double db = dy / (e.getHeight() / 2);

			if ((da * da + db * db) < 1)
				list.add(p);
		}
		return list;
	}

	public void loadTile(String path) {
		try {
			BufferedImage image = ImageIO.read(new File(path));
			width = image.getWidth();
			height = image.getHeight();
			tilepixels = new int[height * width];
			image.getRGB(0, 0, width, height, tilepixels, 0, width);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isDog(Entity e) {
		for (int i = 0; i < entities.size(); i++) {
			Entity p = entities.get(i);
			if(p instanceof Dog) {
			double dx = e.getX() - p.getX();
			double dy = e.getY() - p.getY();
			double da = dx / (e.getWidth() / 2);
			double db = dy / (e.getHeight() / 2);

			if (Math.sqrt(da * da + db * db) < 1) 
				return true;
			}
		}
		return false;
	}
	
	public void loadEntity(String path) {
		try {
			BufferedImage image = ImageIO.read(new File(path));
			width = image.getWidth();
			height = image.getHeight();
			entitypixels = new int[height * width];
			image.getRGB(0, 0, width, height, entitypixels, 0, width);
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (int h = 0; h < height; h++)
			for (int w = 0; w < width; w++) {
				if (entitypixels[w + h * width] == 0xff46c931)
					add(new Ranged(w, h, 27, 15, PATTERN.HORIZONTAL, MODE.HARD));
				if (entitypixels[w + h * width] == 0xff2c941c)
					add(new Ranged(w, h, 27, 15, PATTERN.HORIZONTAL, MODE.EASY));
				if (entitypixels[w + h * width] == 0xff2c941d)
					add(new Ranged(w, h, 27, 15, PATTERN.VERTICAL, MODE.EASY));
				if (entitypixels[w + h * width] == 0xff1acec8)
					add(new Hunter(w, h, 20, 30, PATTERN.VERTICAL, MODE.HARD));
				if (entitypixels[w + h * width] == 0xff1acec9)
					add(new Hunter(w, h, 20, 30, PATTERN.HORIZONTAL, MODE.HARD));
				if (entitypixels[w + h * width] == 0xff116360)
					add(new Hunter(w, h, 20, 30, PATTERN.VERTICAL, MODE.EASY));
				if (entitypixels[w + h * width] == 0xff116361)
					add(new Hunter(w, h, 20, 30, PATTERN.HORIZONTAL, MODE.EASY));
				if (entitypixels[w + h * width] == 0xfff5ca35)
					add(new Tank(w, h, 30, 48, MODE.HARD));
				if (entitypixels[w + h * width] == 0xff856d19)
					add(new Tank(w, h, 30, 48, MODE.EASY));
				if (entitypixels[w + h * width] == 0xff783bbd)
					add(new Boss(w, h, 59, 79));
				if (entitypixels[w + h * width] == 0xffbd3b59)
					add(new Spike(w, h, 16, 16, PATTERN.VERTICAL));
				if (entitypixels[w + h * width] == 0xffbd3b55)
					add(new Spike(w, h, 16, 16, PATTERN.HORIZONTAL));
				if (entitypixels[w + h * width] == 0xff485771)
					add(new Trap(w, h, 16, 16));
				if (entitypixels[w + h * width] == 0xff0c3a03)
					add(new Bubble(w, h, 16, 16));
				if (entitypixels[w + h * width] == 0xfff7883e)
					add(new Dog(w, h, 32, 32));
				if (entitypixels[w + h * width] == 0xff000001)
					add(new Gate(Gate.gateID1, w, h, 16, 16, this));
				if (entitypixels[w + h * width] == 0xff000002)
					add(new Gate(Gate.gateID1, w, h, 16, 16, this));
			}
	}

	public List<Gate> gates() {
		return gates;
	}

	public void add(Gate g) {
		gates.add(g);
	}

	public void add(Entity e) {
		if (e instanceof Player) {
			players.add((Player) e);
		} else if (e instanceof Projectile) {
			projectiles.add((Projectile) e);
		} else if (e instanceof Particle) {
			particles.add((Particle) e);
		} else if (e instanceof Entity) {
			entities.add(e);
		}
		e.setLevel(this);
	}

	public void remove(Entity e) {
		if (e instanceof Player) {
			players.remove((Player) e);
		} else if (e instanceof Projectile) {
			projectiles.remove((Projectile) e);
		} else if (e instanceof Particle) {
			particles.remove((Particle) e);
		} else if (e instanceof Entity) {
			entities.remove(e);
		}
	}

	public Tile getTile(int x, int y) {
		if ((x < 0) || (x >= width) || (y < 0) || (y >= height))
			return Tile.wt1_0_0;
		if (tilepixels[x + y * width] == 0xff000001)
			return new Tile(1);
		if (tilepixels[x + y * width] == 0xff000002)
			return new Tile(1);

		if (tilepixels[x + y * width] == 0xff8f515c)
			return Tile.txt2_0_0;
		if (tilepixels[x + y * width] == 0xff8f515d)
			return Tile.txt2_1_0;
		if (tilepixels[x + y * width] == 0xff8f515e)
			return Tile.txt2_2_0;
		if (tilepixels[x + y * width] == 0xff8f515f)
			return Tile.txt2_3_0;

		if (tilepixels[x + y * width] == 0xff8f5161)
			return Tile.txt2_0_1;
		if (tilepixels[x + y * width] == 0xff8f5162)
			return Tile.txt2_1_1;
		if (tilepixels[x + y * width] == 0xff8f5163)
			return Tile.txt2_2_1;
		if (tilepixels[x + y * width] == 0xff8f5164)
			return Tile.txt2_3_1;

		if (tilepixels[x + y * width] == 0xff8f5165)
			return Tile.txt2_0_2;
		if (tilepixels[x + y * width] == 0xff8f5166)
			return Tile.txt2_1_2;
		if (tilepixels[x + y * width] == 0xff8f5167)
			return Tile.txt2_2_2;
		if (tilepixels[x + y * width] == 0xff8f5168)
			return Tile.txt2_3_2;

		if (tilepixels[x + y * width] == 0xff8f5169)
			return Tile.txt2_0_3;
		if (tilepixels[x + y * width] == 0xff8f516a)
			return Tile.txt2_1_3;
		if (tilepixels[x + y * width] == 0xff8f516b)
			return Tile.txt2_2_3;
		if (tilepixels[x + y * width] == 0xff8f516c)
			return Tile.txt2_3_3;

		if (tilepixels[x + y * width] == 0xff692f3a)
			return Tile.txt2_0_4;
		if (tilepixels[x + y * width] == 0xff692f3b)
			return Tile.txt2_1_4;

		if (tilepixels[x + y * width] == 0xff692f3c)
			return Tile.txt2_0_5;
		if (tilepixels[x + y * width] == 0xff692f3d)
			return Tile.txt2_1_5;

		if (tilepixels[x + y * width] == 0xff5a1925)
			return Tile.txt2_2_4;
		if (tilepixels[x + y * width] == 0xff5a1926)
			return Tile.txt2_3_4;

		if (tilepixels[x + y * width] == 0xff5a1927)
			return Tile.txt2_2_5;
		if (tilepixels[x + y * width] == 0xff5a1928)
			return Tile.txt2_3_5;

		if (tilepixels[x + y * width] == 0xff17152e)
			return Tile.ft1_0_0;
		if (tilepixels[x + y * width] == 0xff17152f)
			return Tile.ft1_1_0;
		if (tilepixels[x + y * width] == 0xff171531)
			return Tile.ft1_2_0;
		if (tilepixels[x + y * width] == 0xff171532)
			return Tile.ft1_3_0;
		if (tilepixels[x + y * width] == 0xff171533)
			return Tile.ft1_4_0;

		if (tilepixels[x + y * width] == 0xff171534)
			return Tile.ft1_0_1;
		if (tilepixels[x + y * width] == 0xff171535)
			return Tile.ft1_1_1;
		if (tilepixels[x + y * width] == 0xff171536)
			return Tile.ft1_2_1;
		if (tilepixels[x + y * width] == 0xff171537)
			return Tile.ft1_3_1;

		if (tilepixels[x + y * width] == 0xff171538)
			return Tile.ft1_0_2;
		if (tilepixels[x + y * width] == 0xff171539)
			return Tile.ft1_1_2;
		if (tilepixels[x + y * width] == 0xff17153a)
			return Tile.ft1_2_2;
		if (tilepixels[x + y * width] == 0xff17153b)
			return Tile.ft1_3_2;

		if (tilepixels[x + y * width] == 0xff17153c)
			return Tile.ft1_0_3;
		if (tilepixels[x + y * width] == 0xff17153d)
			return Tile.ft1_1_3;
		if (tilepixels[x + y * width] == 0xff17153e)
			return Tile.ft1_2_3;
		if (tilepixels[x + y * width] == 0xff17153f)
			return Tile.ft1_3_3;

		if (tilepixels[x + y * width] == 0xff0d0c1e)
			return Tile.ft1_4_0;
		if (tilepixels[x + y * width] == 0xff0d0c1f)
			return Tile.ft1_5_0;
		if (tilepixels[x + y * width] == 0xff0d0c21)
			return Tile.ft1_6_0;
		if (tilepixels[x + y * width] == 0xff0d0c22)
			return Tile.ft1_7_0;

		if (tilepixels[x + y * width] == 0xff2a2f42)
			return Tile.ft1_4_1;
		if (tilepixels[x + y * width] == 0xff2a2f43)
			return Tile.ft1_5_1;
		if (tilepixels[x + y * width] == 0xff2a2f44)
			return Tile.ft1_6_1;
		if (tilepixels[x + y * width] == 0xff2a2f45)
			return Tile.ft1_7_1;

		if (tilepixels[x + y * width] == 0xff2a2f46)
			return Tile.ft1_4_2;
		if (tilepixels[x + y * width] == 0xff2a2f47)
			return Tile.ft1_5_2;
		if (tilepixels[x + y * width] == 0xff2a2f48)
			return Tile.ft1_6_2;
		if (tilepixels[x + y * width] == 0xff2a2f49)
			return Tile.ft1_7_2;

		if (tilepixels[x + y * width] == 0xff2a2f4a)
			return Tile.ft1_4_3;
		if (tilepixels[x + y * width] == 0xff2a2f4b)
			return Tile.ft1_5_3;
		if (tilepixels[x + y * width] == 0xff2a2f4c)
			return Tile.ft1_6_3;
		if (tilepixels[x + y * width] == 0xff2a2f4d)
			return Tile.ft1_7_3;

		if (tilepixels[x + y * width] == 0xff0f0e20)
			return Tile.ft1_0_4;
		if (tilepixels[x + y * width] == 0xff0f0e21)
			return Tile.ft1_1_4;
		if (tilepixels[x + y * width] == 0xff0f0e22)
			return Tile.ft1_2_4;
		if (tilepixels[x + y * width] == 0xff0f0e23)
			return Tile.ft1_3_4;

		if (tilepixels[x + y * width] == 0xff0f0e24)
			return Tile.ft1_0_5;
		if (tilepixels[x + y * width] == 0xff0f0e25)
			return Tile.ft1_1_5;
		if (tilepixels[x + y * width] == 0xff0f0e26)
			return Tile.ft1_2_5;
		if (tilepixels[x + y * width] == 0xff0f0e27)
			return Tile.ft1_3_5;

		if (tilepixels[x + y * width] == 0xff0f0e28)
			return Tile.ft1_0_6;
		if (tilepixels[x + y * width] == 0xff0f0e29)
			return Tile.ft1_1_6;
		if (tilepixels[x + y * width] == 0xff0f0e2a)
			return Tile.ft1_2_6;
		if (tilepixels[x + y * width] == 0xff0f0e2b)
			return Tile.ft1_3_6;

		if (tilepixels[x + y * width] == 0xff0f0e2c)
			return Tile.ft1_0_7;
		if (tilepixels[x + y * width] == 0xff0f0e2d)
			return Tile.ft1_1_7;
		if (tilepixels[x + y * width] == 0xff0f0e2e)
			return Tile.ft1_2_7;
		if (tilepixels[x + y * width] == 0xff0f0e2f)
			return Tile.ft1_3_7;

		if (tilepixels[x + y * width] == 0xff212724)
			return Tile.ft1_4_4;
		if (tilepixels[x + y * width] == 0xff212725)
			return Tile.ft1_5_4;
		if (tilepixels[x + y * width] == 0xff212726)
			return Tile.ft1_6_4;
		if (tilepixels[x + y * width] == 0xff212727)
			return Tile.ft1_7_4;

		if (tilepixels[x + y * width] == 0xff212728)
			return Tile.ft1_4_5;
		if (tilepixels[x + y * width] == 0xff212729)
			return Tile.ft1_5_5;
		if (tilepixels[x + y * width] == 0xff21272a)
			return Tile.ft1_6_5;
		if (tilepixels[x + y * width] == 0xff21272b)
			return Tile.ft1_7_5;

		if (tilepixels[x + y * width] == 0xff21272c)
			return Tile.ft1_4_6;
		if (tilepixels[x + y * width] == 0xff21272d)
			return Tile.ft1_5_6;
		if (tilepixels[x + y * width] == 0xff21272e)
			return Tile.ft1_6_6;
		if (tilepixels[x + y * width] == 0xff21272f)
			return Tile.ft1_7_6;

		if (tilepixels[x + y * width] == 0xff212731)
			return Tile.ft1_4_7;
		if (tilepixels[x + y * width] == 0xff212732)
			return Tile.ft1_5_7;
		if (tilepixels[x + y * width] == 0xff212733)
			return Tile.ft1_6_7;
		if (tilepixels[x + y * width] == 0xff212734)
			return Tile.ft1_7_7;

		if (tilepixels[x + y * width] == 0xff595b68)
			return Tile.ft2_0_0;
		if (tilepixels[x + y * width] == 0xff595b69)
			return Tile.ft2_1_0;
		if (tilepixels[x + y * width] == 0xff595b6a)
			return Tile.ft2_2_0;
		if (tilepixels[x + y * width] == 0xff595b6b)
			return Tile.ft2_3_0;

		if (tilepixels[x + y * width] == 0xff595b6c)
			return Tile.ft2_0_1;
		if (tilepixels[x + y * width] == 0xff595b6d)
			return Tile.ft2_1_1;
		if (tilepixels[x + y * width] == 0xff595b6e)
			return Tile.ft2_2_1;
		if (tilepixels[x + y * width] == 0xff595b6f)
			return Tile.ft2_3_1;

		if (tilepixels[x + y * width] == 0xff595b71)
			return Tile.ft2_0_2;
		if (tilepixels[x + y * width] == 0xff595b72)
			return Tile.ft2_1_2;
		if (tilepixels[x + y * width] == 0xff595b73)
			return Tile.ft2_2_2;
		if (tilepixels[x + y * width] == 0xff595b74)
			return Tile.ft2_3_2;

		if (tilepixels[x + y * width] == 0xff595b75)
			return Tile.ft2_0_3;
		if (tilepixels[x + y * width] == 0xff595b76)
			return Tile.ft2_1_3;
		if (tilepixels[x + y * width] == 0xff595b77)
			return Tile.ft2_2_3;
		if (tilepixels[x + y * width] == 0xff595b78)
			return Tile.ft2_3_3;

		if (tilepixels[x + y * width] == 0xff1e1621)
			return Tile.ft2_4_0;
		if (tilepixels[x + y * width] == 0xff1e1622)
			return Tile.ft2_5_0;
		if (tilepixels[x + y * width] == 0xff1e1623)
			return Tile.ft2_6_0;
		if (tilepixels[x + y * width] == 0xff1e1624)
			return Tile.ft2_7_0;

		if (tilepixels[x + y * width] == 0xff1e1625)
			return Tile.ft2_4_1;
		if (tilepixels[x + y * width] == 0xff1e1626)
			return Tile.ft2_5_1;
		if (tilepixels[x + y * width] == 0xff1e1627)
			return Tile.ft2_6_1;
		if (tilepixels[x + y * width] == 0xff1e1628)
			return Tile.ft2_7_1;

		if (tilepixels[x + y * width] == 0xff1e1629)
			return Tile.ft2_4_2;
		if (tilepixels[x + y * width] == 0xff1e162a)
			return Tile.ft2_5_2;
		if (tilepixels[x + y * width] == 0xff1e162b)
			return Tile.ft2_6_2;
		if (tilepixels[x + y * width] == 0xff1e162c)
			return Tile.ft2_7_2;

		if (tilepixels[x + y * width] == 0xff1e162d)
			return Tile.ft2_4_3;
		if (tilepixels[x + y * width] == 0xff1e162e)
			return Tile.ft2_5_3;
		if (tilepixels[x + y * width] == 0xff1e162f)
			return Tile.ft2_6_3;
		if (tilepixels[x + y * width] == 0xff1e1631)
			return Tile.ft2_7_3;

		if (tilepixels[x + y * width] == 0xff755e3a)
			return Tile.ft2_0_4;
		if (tilepixels[x + y * width] == 0xff755e3b)
			return Tile.ft2_1_4;
		if (tilepixels[x + y * width] == 0xff755e3c)
			return Tile.ft2_2_4;

		if (tilepixels[x + y * width] == 0xff755e3d)
			return Tile.ft2_0_5;
		if (tilepixels[x + y * width] == 0xff755e3e)
			return Tile.ft2_1_5;
		if (tilepixels[x + y * width] == 0xff755e3f)
			return Tile.ft2_2_5;

		if (tilepixels[x + y * width] == 0xff755e41)
			return Tile.ft2_0_6;
		if (tilepixels[x + y * width] == 0xff755e42)
			return Tile.ft2_1_6;
		if (tilepixels[x + y * width] == 0xff755e43)
			return Tile.ft2_2_6;

		if (tilepixels[x + y * width] == 0xff755e44)
			return Tile.ft2_0_7;
		if (tilepixels[x + y * width] == 0xff755e45)
			return Tile.ft2_1_7;
		if (tilepixels[x + y * width] == 0xff755e46)
			return Tile.ft2_2_7;

		if (tilepixels[x + y * width] == 0xff485e3c)
			return Tile.ft2_3_4;
		if (tilepixels[x + y * width] == 0xff485e3d)
			return Tile.ft2_4_4;
		if (tilepixels[x + y * width] == 0xff485e3e)
			return Tile.ft2_5_4;
		if (tilepixels[x + y * width] == 0xff485e3f)
			return Tile.ft2_6_4;
		if (tilepixels[x + y * width] == 0xff485e41)
			return Tile.ft2_7_4;

		if (tilepixels[x + y * width] == 0xff485e42)
			return Tile.ft2_3_5;
		if (tilepixels[x + y * width] == 0xff485e43)
			return Tile.ft2_4_5;
		if (tilepixels[x + y * width] == 0xff485e44)
			return Tile.ft2_5_5;
		if (tilepixels[x + y * width] == 0xff485e45)
			return Tile.ft2_6_5;
		if (tilepixels[x + y * width] == 0xff485e46)
			return Tile.ft2_7_5;

		if (tilepixels[x + y * width] == 0xff485e47)
			return Tile.ft2_3_6;
		if (tilepixels[x + y * width] == 0xff485e48)
			return Tile.ft2_4_6;
		if (tilepixels[x + y * width] == 0xff485e49)
			return Tile.ft2_5_6;
		if (tilepixels[x + y * width] == 0xff485e4a)
			return Tile.ft2_6_6;
		if (tilepixels[x + y * width] == 0xff485e4b)
			return Tile.ft2_7_6;

		if (tilepixels[x + y * width] == 0xff485e4c)
			return Tile.ft2_3_7;
		if (tilepixels[x + y * width] == 0xff485e4d)
			return Tile.ft2_4_7;
		if (tilepixels[x + y * width] == 0xff485e4e)
			return Tile.ft2_5_7;
		if (tilepixels[x + y * width] == 0xff485e4f)
			return Tile.ft2_6_7;
		if (tilepixels[x + y * width] == 0xff485e51)
			return Tile.ft2_7_7;

		if (tilepixels[x + y * width] == 0xff2f3c52)
			return Tile.wt1_0_0;
		if (tilepixels[x + y * width] == 0xff2f3c53)
			return Tile.wt1_1_0;
		if (tilepixels[x + y * width] == 0xff2f3c54)
			return Tile.wt1_2_0;
		if (tilepixels[x + y * width] == 0xff2f3c55)
			return Tile.wt1_3_0;
		if (tilepixels[x + y * width] == 0xff2f3c56)
			return Tile.wt1_4_0;

		if (tilepixels[x + y * width] == 0xff2f3c57)
			return Tile.wt1_0_1;
		if (tilepixels[x + y * width] == 0xff2f3c58)
			return Tile.wt1_1_1;
		if (tilepixels[x + y * width] == 0xff2f3c59)
			return Tile.wt1_2_1;
		if (tilepixels[x + y * width] == 0xff2f3c5a)
			return Tile.wt1_3_1;
		if (tilepixels[x + y * width] == 0xff2f3c5b)
			return Tile.wt1_4_1;

		if (tilepixels[x + y * width] == 0xff2f3c5c)
			return Tile.wt1_0_2;
		if (tilepixels[x + y * width] == 0xff2f3c5d)
			return Tile.wt1_1_2;
		if (tilepixels[x + y * width] == 0xff2f3c5e)
			return Tile.wt1_2_2;
		if (tilepixels[x + y * width] == 0xff2f3c5f)
			return Tile.wt1_3_2;
		if (tilepixels[x + y * width] == 0xff2f3c61)
			return Tile.wt1_4_2;

		if (tilepixels[x + y * width] == 0xff2f3c62)
			return Tile.wt1_5_0;
		if (tilepixels[x + y * width] == 0xff2f3c63)
			return Tile.wt1_6_0;
		if (tilepixels[x + y * width] == 0xff2f3c64)
			return Tile.wt1_7_0;

		if (tilepixels[x + y * width] == 0xff2f3c65)
			return Tile.wt1_5_1;
		if (tilepixels[x + y * width] == 0xff2f3c66)
			return Tile.wt1_6_1;
		if (tilepixels[x + y * width] == 0xff2f3c67)
			return Tile.wt1_7_1;

		if (tilepixels[x + y * width] == 0xff2f3c68)
			return Tile.wt1_5_2;
		if (tilepixels[x + y * width] == 0xff2f3c69)
			return Tile.wt1_6_2;
		if (tilepixels[x + y * width] == 0xff2f3c6a)
			return Tile.wt1_7_2;

		if (tilepixels[x + y * width] == 0xff8e9599)
			return Tile.wt1_0_3;
		if (tilepixels[x + y * width] == 0xff8e959a)
			return Tile.wt1_1_3;
		if (tilepixels[x + y * width] == 0xff8e959b)
			return Tile.wt1_2_3;
		if (tilepixels[x + y * width] == 0xff8e959c)
			return Tile.wt1_3_3;
		if (tilepixels[x + y * width] == 0xff8e959d)
			return Tile.wt1_4_3;

		if (tilepixels[x + y * width] == 0xff8e959e)
			return Tile.wt1_0_4;
		if (tilepixels[x + y * width] == 0xff8e959f)
			return Tile.wt1_1_4;
		if (tilepixels[x + y * width] == 0xff8e95a1)
			return Tile.wt1_2_4;
		if (tilepixels[x + y * width] == 0xff8e95a2)
			return Tile.wt1_3_4;
		if (tilepixels[x + y * width] == 0xff8e95a3)
			return Tile.wt1_4_4;

		if (tilepixels[x + y * width] == 0xff8e95a4)
			return Tile.wt1_5_3;
		if (tilepixels[x + y * width] == 0xff8e95a5)
			return Tile.wt1_6_3;
		if (tilepixels[x + y * width] == 0xff8e95a6)
			return Tile.wt1_7_3;

		if (tilepixels[x + y * width] == 0xff8e95a7)
			return Tile.wt1_5_4;
		if (tilepixels[x + y * width] == 0xff8e95a8)
			return Tile.wt1_6_4;
		if (tilepixels[x + y * width] == 0xff8e95a9)
			return Tile.wt1_7_4;

		if (tilepixels[x + y * width] == 0xff3e3e45)
			return Tile.wt1_0_5;
		if (tilepixels[x + y * width] == 0xff3e3e46)
			return Tile.wt1_1_5;
		if (tilepixels[x + y * width] == 0xff3e3e47)
			return Tile.wt1_2_5;
		if (tilepixels[x + y * width] == 0xff3e3e48)
			return Tile.wt1_3_5;
		if (tilepixels[x + y * width] == 0xff3e3e49)
			return Tile.wt1_4_5;

		if (tilepixels[x + y * width] == 0xff3e3e4a)
			return Tile.wt1_0_6;
		if (tilepixels[x + y * width] == 0xff3e3e4b)
			return Tile.wt1_1_6;
		if (tilepixels[x + y * width] == 0xff3e3e4c)
			return Tile.wt1_2_6;
		if (tilepixels[x + y * width] == 0xff3e3e4d)
			return Tile.wt1_3_6;
		if (tilepixels[x + y * width] == 0xff3e3e4e)
			return Tile.wt1_4_6;

		if (tilepixels[x + y * width] == 0xff3e3e4f)
			return Tile.wt1_0_7;
		if (tilepixels[x + y * width] == 0xff3e3e51)
			return Tile.wt1_1_7;
		if (tilepixels[x + y * width] == 0xff3e3e52)
			return Tile.wt1_2_7;
		if (tilepixels[x + y * width] == 0xff3e3e53)
			return Tile.wt1_3_7;
		if (tilepixels[x + y * width] == 0xff3e3e54)
			return Tile.wt1_4_7;

		if (tilepixels[x + y * width] == 0xff3e3e55)
			return Tile.wt1_5_5;
		if (tilepixels[x + y * width] == 0xff3e3e56)
			return Tile.wt1_6_5;
		if (tilepixels[x + y * width] == 0xff3e3e57)
			return Tile.wt1_7_5;

		if (tilepixels[x + y * width] == 0xff3e3e58)
			return Tile.wt1_5_6;
		if (tilepixels[x + y * width] == 0xff3e3e59)
			return Tile.wt1_6_6;
		if (tilepixels[x + y * width] == 0xff3e3e5a)
			return Tile.wt1_7_6;

		if (tilepixels[x + y * width] == 0xff3e3e5b)
			return Tile.wt1_5_7;
		if (tilepixels[x + y * width] == 0xff3e3e5c)
			return Tile.wt1_6_7;
		if (tilepixels[x + y * width] == 0xff3e3e5d)
			return Tile.wt1_7_7;

		if (tilepixels[x + y * width] == 0xff79828d)
			return Tile.wt2_0_0;
		if (tilepixels[x + y * width] == 0xff79828e)
			return Tile.wt2_1_0;
		if (tilepixels[x + y * width] == 0xff79828f)
			return Tile.wt2_2_0;
		if (tilepixels[x + y * width] == 0xff798291)
			return Tile.wt2_3_0;

		if (tilepixels[x + y * width] == 0xff798292)
			return Tile.wt2_0_1;
		if (tilepixels[x + y * width] == 0xff798293)
			return Tile.wt2_1_1;
		if (tilepixels[x + y * width] == 0xff798294)
			return Tile.wt2_2_1;
		if (tilepixels[x + y * width] == 0xff798295)
			return Tile.wt2_3_1;

		if (tilepixels[x + y * width] == 0xff798296)
			return Tile.wt2_4_0;
		if (tilepixels[x + y * width] == 0xff798297)
			return Tile.wt2_5_0;
		if (tilepixels[x + y * width] == 0xff798298)
			return Tile.wt2_6_0;
		if (tilepixels[x + y * width] == 0xff798299)
			return Tile.wt2_7_0;

		if (tilepixels[x + y * width] == 0xff79829a)
			return Tile.wt2_4_1;
		if (tilepixels[x + y * width] == 0xff79829b)
			return Tile.wt2_5_1;
		if (tilepixels[x + y * width] == 0xff79829c)
			return Tile.wt2_6_1;
		if (tilepixels[x + y * width] == 0xff79829d)
			return Tile.wt2_7_1;

		if (tilepixels[x + y * width] == 0xff686661)
			return Tile.wt2_0_2;
		if (tilepixels[x + y * width] == 0xff686662)
			return Tile.wt2_1_2;
		if (tilepixels[x + y * width] == 0xff686663)
			return Tile.wt2_2_2;
		if (tilepixels[x + y * width] == 0xff686664)
			return Tile.wt2_3_2;

		if (tilepixels[x + y * width] == 0xff686665)
			return Tile.wt2_0_3;
		if (tilepixels[x + y * width] == 0xff686666)
			return Tile.wt2_1_3;
		if (tilepixels[x + y * width] == 0xff686667)
			return Tile.wt2_2_3;
		if (tilepixels[x + y * width] == 0xff686668)
			return Tile.wt2_3_3;

		if (tilepixels[x + y * width] == 0xff686669)
			return Tile.wt2_4_2;
		if (tilepixels[x + y * width] == 0xff68666a)
			return Tile.wt2_5_2;
		if (tilepixels[x + y * width] == 0xff68666b)
			return Tile.wt2_6_2;
		if (tilepixels[x + y * width] == 0xff68666c)
			return Tile.wt2_7_2;

		if (tilepixels[x + y * width] == 0xff68666d)
			return Tile.wt2_4_3;
		if (tilepixels[x + y * width] == 0xff68666e)
			return Tile.wt2_5_3;
		if (tilepixels[x + y * width] == 0xff68666f)
			return Tile.wt2_6_3;
		if (tilepixels[x + y * width] == 0xff686671)
			return Tile.wt2_7_3;

		if (tilepixels[x + y * width] == 0xff485769)
			return Tile.wt2_0_4;
		if (tilepixels[x + y * width] == 0xff48576a)
			return Tile.wt2_1_4;
		if (tilepixels[x + y * width] == 0xff48576b)
			return Tile.wt2_2_4;
		if (tilepixels[x + y * width] == 0xff48576c)
			return Tile.wt2_3_4;

		if (tilepixels[x + y * width] == 0xff48576d)
			return Tile.wt2_0_5;
		if (tilepixels[x + y * width] == 0xff48576e)
			return Tile.wt2_1_5;
		if (tilepixels[x + y * width] == 0xff48576f)
			return Tile.wt2_2_5;
		if (tilepixels[x + y * width] == 0xff485771)
			return Tile.wt2_3_5;

		if (tilepixels[x + y * width] == 0xff425a85)
			return Tile.wt2_4_4;
		if (tilepixels[x + y * width] == 0xff425a86)
			return Tile.wt2_5_4;
		if (tilepixels[x + y * width] == 0xff425a87)
			return Tile.wt2_6_4;
		if (tilepixels[x + y * width] == 0xff425a88)
			return Tile.wt2_7_4;

		if (tilepixels[x + y * width] == 0xff425a89)
			return Tile.wt2_4_5;
		if (tilepixels[x + y * width] == 0xff425a8a)
			return Tile.wt2_5_5;
		if (tilepixels[x + y * width] == 0xff425a8b)
			return Tile.wt2_6_5;
		if (tilepixels[x + y * width] == 0xff425a8c)
			return Tile.wt2_7_5;

		if (tilepixels[x + y * width] == 0xff272b3e)
			return Tile.wt2_0_6;
		if (tilepixels[x + y * width] == 0xff272b3f)
			return Tile.wt2_1_6;
		if (tilepixels[x + y * width] == 0xff272b41)
			return Tile.wt2_2_6;
		if (tilepixels[x + y * width] == 0xff272b42)
			return Tile.wt2_3_6;

		if (tilepixels[x + y * width] == 0xff73664c)
			return Tile.wt2_4_6;
		if (tilepixels[x + y * width] == 0xff73664d)
			return Tile.wt2_5_6;
		if (tilepixels[x + y * width] == 0xff73664e)
			return Tile.wt2_6_6;
		if (tilepixels[x + y * width] == 0xff73664f)
			return Tile.wt2_7_6;

		if (tilepixels[x + y * width] == 0xff1d2627)
			return Tile.wt3_0_0;
		if (tilepixels[x + y * width] == 0xff1d2628)
			return Tile.wt3_1_0;
		if (tilepixels[x + y * width] == 0xff1d2629)
			return Tile.wt3_2_0;
		if (tilepixels[x + y * width] == 0xff1d262a)
			return Tile.wt3_3_0;

		if (tilepixels[x + y * width] == 0xff1d262b)
			return Tile.wt3_4_0;
		if (tilepixels[x + y * width] == 0xff1d262c)
			return Tile.wt3_5_0;
		if (tilepixels[x + y * width] == 0xff1d262d)
			return Tile.wt3_6_0;
		if (tilepixels[x + y * width] == 0xff1d262e)
			return Tile.wt3_7_0;

		if (tilepixels[x + y * width] == 0xff1d262f)
			return Tile.wt3_0_1;
		if (tilepixels[x + y * width] == 0xff1d2630)
			return Tile.wt3_1_1;
		if (tilepixels[x + y * width] == 0xff1d2631)
			return Tile.wt3_2_1;
		if (tilepixels[x + y * width] == 0xff1d2632)
			return Tile.wt3_3_1;

		if (tilepixels[x + y * width] == 0xff1d2633)
			return Tile.wt3_4_1;
		if (tilepixels[x + y * width] == 0xff1d2634)
			return Tile.wt3_5_1;
		if (tilepixels[x + y * width] == 0xff1d2635)
			return Tile.wt3_6_1;
		if (tilepixels[x + y * width] == 0xff1d2636)
			return Tile.wt3_7_1;

		if (tilepixels[x + y * width] == 0xff3f4d48)
			return Tile.wt3_0_2;
		if (tilepixels[x + y * width] == 0xff3f4d49)
			return Tile.wt3_1_2;
		if (tilepixels[x + y * width] == 0xff3f4d4a)
			return Tile.wt3_2_2;
		if (tilepixels[x + y * width] == 0xff3f4d4b)
			return Tile.wt3_3_2;

		if (tilepixels[x + y * width] == 0xff3f4d4c)
			return Tile.wt3_4_2;
		if (tilepixels[x + y * width] == 0xff3f4d4d)
			return Tile.wt3_5_2;
		if (tilepixels[x + y * width] == 0xff3f4d4e)
			return Tile.wt3_6_2;
		if (tilepixels[x + y * width] == 0xff3f4d4f)
			return Tile.wt3_7_2;

		if (tilepixels[x + y * width] == 0xff3f4d50)
			return Tile.wt3_0_3;
		if (tilepixels[x + y * width] == 0xff3f4d51)
			return Tile.wt3_1_3;
		if (tilepixels[x + y * width] == 0xff3f4d52)
			return Tile.wt3_2_3;
		if (tilepixels[x + y * width] == 0xff3f4d53)
			return Tile.wt3_3_3;

		if (tilepixels[x + y * width] == 0xff3f4d54)
			return Tile.wt3_4_3;
		if (tilepixels[x + y * width] == 0xff3f4d55)
			return Tile.wt3_5_3;
		if (tilepixels[x + y * width] == 0xff3f4d56)
			return Tile.wt3_6_3;
		if (tilepixels[x + y * width] == 0xff3f4d57)
			return Tile.wt3_7_3;

		if (tilepixels[x + y * width] == 0xff0a0914)
			return Tile.wt3_0_4;
		if (tilepixels[x + y * width] == 0xff0a0915)
			return Tile.wt3_1_4;
		if (tilepixels[x + y * width] == 0xff0a0916)
			return Tile.wt3_2_4;
		if (tilepixels[x + y * width] == 0xff0a0917)
			return Tile.wt3_3_4;

		if (tilepixels[x + y * width] == 0xff0a0918)
			return Tile.wt3_4_4;
		if (tilepixels[x + y * width] == 0xff0a0919)
			return Tile.wt3_5_4;
		if (tilepixels[x + y * width] == 0xff0a091a)
			return Tile.wt3_6_4;
		if (tilepixels[x + y * width] == 0xff0a091b)
			return Tile.wt3_7_4;

		if (tilepixels[x + y * width] == 0xff0a091c)
			return Tile.wt3_0_5;
		if (tilepixels[x + y * width] == 0xff0a091d)
			return Tile.wt3_1_5;
		if (tilepixels[x + y * width] == 0xff0a091e)
			return Tile.wt3_2_5;
		if (tilepixels[x + y * width] == 0xff0a091f)
			return Tile.wt3_3_5;

		if (tilepixels[x + y * width] == 0xff0a0920)
			return Tile.wt3_4_5;
		if (tilepixels[x + y * width] == 0xff0a0921)
			return Tile.wt3_5_5;
		if (tilepixels[x + y * width] == 0xff0a0922)
			return Tile.wt3_6_5;
		if (tilepixels[x + y * width] == 0xff0a0923)
			return Tile.wt3_7_5;

		if (tilepixels[x + y * width] == 0xff222138)
			return Tile.wt3_0_6;
		if (tilepixels[x + y * width] == 0xff222139)
			return Tile.wt3_1_6;
		if (tilepixels[x + y * width] == 0xff22213a)
			return Tile.wt3_2_6;
		if (tilepixels[x + y * width] == 0xff22213b)
			return Tile.wt3_3_6;

		if (tilepixels[x + y * width] == 0xff22213c)
			return Tile.wt3_4_6;
		if (tilepixels[x + y * width] == 0xff22213d)
			return Tile.wt3_5_6;
		if (tilepixels[x + y * width] == 0xff22213e)
			return Tile.wt3_6_6;
		if (tilepixels[x + y * width] == 0xff22213f)
			return Tile.wt3_7_6;

		if (tilepixels[x + y * width] == 0xff222140)
			return Tile.wt3_0_7;
		if (tilepixels[x + y * width] == 0xff222141)
			return Tile.wt3_1_7;
		if (tilepixels[x + y * width] == 0xff222142)
			return Tile.wt3_2_7;
		if (tilepixels[x + y * width] == 0xff222143)
			return Tile.wt3_3_7;

		if (tilepixels[x + y * width] == 0xff222144)
			return Tile.wt3_4_7;
		if (tilepixels[x + y * width] == 0xff222145)
			return Tile.wt3_5_7;
		if (tilepixels[x + y * width] == 0xff222146)
			return Tile.wt3_6_7;
		if (tilepixels[x + y * width] == 0xff222147)
			return Tile.wt3_7_7;

		return Tile.wt1_0_0;
	}

	public void update() {
		for (int i = 0; i < players.size(); i++) {
			players.get(i).update();

		}
		for (int j = 0; j < projectiles.size(); j++) {
			projectiles.get(j).update();
		}
		for (int j = 0; j < particles.size(); j++) {
			particles.get(j).update();
		}
		for (int j = 0; j < entities.size(); j++) {
			entities.get(j).update();
		}
	}

	public void render(Screen screen) {
		int xl = screen.getX_ofs() >> 4;
		int xr = ((screen.getX_ofs() + screen.getWidth()) >> 4) + 1;
		int yh = screen.getY_ofs() >> 4;
		int yl = ((screen.getY_ofs() + screen.getHeight()) >> 4) + 1;

		for (int y = yh; y < yl; y++)
			for (int x = xl; x < xr; x++) {
				getTile(x, y).render(x << 4, y << 4, screen);
			}

		for (int i = 0; i < players.size(); i++) {
			players.get(i).render(screen);
		}
		for (int j = 0; j < projectiles.size(); j++) {
			projectiles.get(j).render(screen);
		}
		for (int j = 0; j < entities.size(); j++) {
			entities.get(j).render(screen);
		}
		for (int j = 0; j < particles.size(); j++) {
			particles.get(j).render(screen);
		}
	}

}
