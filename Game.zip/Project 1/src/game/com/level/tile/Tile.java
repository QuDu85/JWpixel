package game.com.level.tile;

//import java.util.ArrayList;
//import java.util.List;

import game.com.level.spritesheet.Sprite;
import game.com.level.spritesheet.SpriteSheet;
import game.com.screen.Screen;

public class Tile {
	public final static Tile ft1_0_0 = new Tile(new Sprite(0,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_0 = new Tile(new Sprite(1,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_0 = new Tile(new Sprite(2,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_0 = new Tile(new Sprite(3,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_0 = new Tile(new Sprite(4,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_0 = new Tile(new Sprite(5,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_0 = new Tile(new Sprite(6,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_0 = new Tile(new Sprite(7,0,SpriteSheet.floortile1),false);
	
	public final static Tile ft1_0_1 = new Tile(new Sprite(0,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_1 = new Tile(new Sprite(1,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_1 = new Tile(new Sprite(2,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_1 = new Tile(new Sprite(3,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_1 = new Tile(new Sprite(4,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_1 = new Tile(new Sprite(5,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_1 = new Tile(new Sprite(6,0,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_1 = new Tile(new Sprite(7,0,SpriteSheet.floortile1),false);
	
	public final static Tile ft1_0_2 = new Tile(new Sprite(0,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_2 = new Tile(new Sprite(1,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_2 = new Tile(new Sprite(2,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_2 = new Tile(new Sprite(3,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_2 = new Tile(new Sprite(4,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_2 = new Tile(new Sprite(5,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_2 = new Tile(new Sprite(6,2,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_2 = new Tile(new Sprite(7,2,SpriteSheet.floortile1),false);

	public final static Tile ft1_0_3 = new Tile(new Sprite(0,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_3 = new Tile(new Sprite(1,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_3 = new Tile(new Sprite(2,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_3 = new Tile(new Sprite(3,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_3 = new Tile(new Sprite(4,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_3 = new Tile(new Sprite(5,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_3 = new Tile(new Sprite(6,3,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_3 = new Tile(new Sprite(7,3,SpriteSheet.floortile1),false);

	public final static Tile ft1_0_4 = new Tile(new Sprite(0,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_4 = new Tile(new Sprite(1,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_4 = new Tile(new Sprite(2,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_4 = new Tile(new Sprite(3,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_4 = new Tile(new Sprite(4,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_4 = new Tile(new Sprite(5,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_4 = new Tile(new Sprite(6,4,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_4 = new Tile(new Sprite(7,4,SpriteSheet.floortile1),false);

	public final static Tile ft1_0_5 = new Tile(new Sprite(0,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_5 = new Tile(new Sprite(1,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_5 = new Tile(new Sprite(2,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_5 = new Tile(new Sprite(3,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_5 = new Tile(new Sprite(4,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_5 = new Tile(new Sprite(5,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_5 = new Tile(new Sprite(6,5,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_5 = new Tile(new Sprite(7,5,SpriteSheet.floortile1),false);

	public final static Tile ft1_0_6 = new Tile(new Sprite(0,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_6 = new Tile(new Sprite(1,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_6 = new Tile(new Sprite(2,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_6 = new Tile(new Sprite(3,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_6 = new Tile(new Sprite(4,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_6 = new Tile(new Sprite(5,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_6 = new Tile(new Sprite(6,6,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_6 = new Tile(new Sprite(7,6,SpriteSheet.floortile1),false);

	public final static Tile ft1_0_7 = new Tile(new Sprite(0,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_1_7 = new Tile(new Sprite(1,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_2_7 = new Tile(new Sprite(2,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_3_7 = new Tile(new Sprite(3,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_4_7 = new Tile(new Sprite(4,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_5_7 = new Tile(new Sprite(5,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_6_7 = new Tile(new Sprite(6,7,SpriteSheet.floortile1),false);
	public final static Tile ft1_7_7 = new Tile(new Sprite(7,7,SpriteSheet.floortile1),false);
	
	public final static Tile ft2_0_0 = new Tile(new Sprite(0,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_0 = new Tile(new Sprite(1,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_0 = new Tile(new Sprite(2,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_0 = new Tile(new Sprite(3,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_4_0 = new Tile(new Sprite(4,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_5_0 = new Tile(new Sprite(5,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_6_0 = new Tile(new Sprite(6,0,SpriteSheet.floortile2),false);
	public final static Tile ft2_7_0 = new Tile(new Sprite(7,0,SpriteSheet.floortile2),false);
	
	public final static Tile ft2_0_1 = new Tile(new Sprite(0,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_1 = new Tile(new Sprite(1,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_1 = new Tile(new Sprite(2,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_1 = new Tile(new Sprite(3,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_4_1 = new Tile(new Sprite(4,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_5_1 = new Tile(new Sprite(5,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_6_1 = new Tile(new Sprite(6,1,SpriteSheet.floortile2),false);
	public final static Tile ft2_7_1 = new Tile(new Sprite(7,1,SpriteSheet.floortile2),false);

	public final static Tile ft2_0_2 = new Tile(new Sprite(0,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_2 = new Tile(new Sprite(1,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_2 = new Tile(new Sprite(2,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_2 = new Tile(new Sprite(3,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_4_2 = new Tile(new Sprite(4,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_5_2 = new Tile(new Sprite(5,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_6_2 = new Tile(new Sprite(6,2,SpriteSheet.floortile2),false);
	public final static Tile ft2_7_2 = new Tile(new Sprite(7,2,SpriteSheet.floortile2),false);

	public final static Tile ft2_0_3 = new Tile(new Sprite(0,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_3 = new Tile(new Sprite(1,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_3 = new Tile(new Sprite(2,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_3 = new Tile(new Sprite(3,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_4_3 = new Tile(new Sprite(4,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_5_3 = new Tile(new Sprite(5,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_6_3 = new Tile(new Sprite(6,3,SpriteSheet.floortile2),false);
	public final static Tile ft2_7_3 = new Tile(new Sprite(7,3,SpriteSheet.floortile2),false);

	public final static Tile ft2_0_4 = new Tile(new Sprite(0,4,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_4 = new Tile(new Sprite(1,4,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_4 = new Tile(new Sprite(2,4,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_4 = new Tile(new Sprite(3,4,SpriteSheet.floortile2),true);
	public final static Tile ft2_4_4 = new Tile(new Sprite(4,4,SpriteSheet.floortile2),true);
	public final static Tile ft2_5_4 = new Tile(new Sprite(5,4,SpriteSheet.floortile2),true);
	public final static Tile ft2_6_4 = new Tile(new Sprite(6,4,SpriteSheet.floortile2),true);
	public final static Tile ft2_7_4 = new Tile(new Sprite(7,4,SpriteSheet.floortile2),true);

	public final static Tile ft2_0_5 = new Tile(new Sprite(0,5,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_5 = new Tile(new Sprite(1,5,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_5 = new Tile(new Sprite(2,5,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_5 = new Tile(new Sprite(3,5,SpriteSheet.floortile2),true);
	public final static Tile ft2_4_5 = new Tile(new Sprite(4,5,SpriteSheet.floortile2),true);
	public final static Tile ft2_5_5 = new Tile(new Sprite(5,5,SpriteSheet.floortile2),true);
	public final static Tile ft2_6_5 = new Tile(new Sprite(6,5,SpriteSheet.floortile2),true);
	public final static Tile ft2_7_5 = new Tile(new Sprite(7,5,SpriteSheet.floortile2),true);

	public final static Tile ft2_0_6 = new Tile(new Sprite(0,6,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_6 = new Tile(new Sprite(1,6,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_6 = new Tile(new Sprite(2,6,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_6 = new Tile(new Sprite(3,6,SpriteSheet.floortile2),true);
	public final static Tile ft2_4_6 = new Tile(new Sprite(4,6,SpriteSheet.floortile2),true);
	public final static Tile ft2_5_6 = new Tile(new Sprite(5,6,SpriteSheet.floortile2),true);
	public final static Tile ft2_6_6 = new Tile(new Sprite(6,6,SpriteSheet.floortile2),true);
	public final static Tile ft2_7_6 = new Tile(new Sprite(7,6,SpriteSheet.floortile2),true);

	public final static Tile ft2_0_7 = new Tile(new Sprite(0,7,SpriteSheet.floortile2),false);
	public final static Tile ft2_1_7 = new Tile(new Sprite(1,7,SpriteSheet.floortile2),false);
	public final static Tile ft2_2_7 = new Tile(new Sprite(2,7,SpriteSheet.floortile2),false);
	public final static Tile ft2_3_7 = new Tile(new Sprite(3,7,SpriteSheet.floortile2),true);
	public final static Tile ft2_4_7 = new Tile(new Sprite(4,7,SpriteSheet.floortile2),true);
	public final static Tile ft2_5_7 = new Tile(new Sprite(5,7,SpriteSheet.floortile2),true);
	public final static Tile ft2_6_7 = new Tile(new Sprite(6,7,SpriteSheet.floortile2),true);
	public final static Tile ft2_7_7 = new Tile(new Sprite(7,7,SpriteSheet.floortile2),true);
	
	public final static Tile wt1_0_0 = new Tile(new Sprite(0,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_0 = new Tile(new Sprite(1,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_0 = new Tile(new Sprite(2,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_0 = new Tile(new Sprite(3,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_0 = new Tile(new Sprite(4,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_0 = new Tile(new Sprite(5,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_0 = new Tile(new Sprite(6,0,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_0 = new Tile(new Sprite(7,0,SpriteSheet.walltile1),true);
	
	public final static Tile wt1_0_1 = new Tile(new Sprite(0,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_1 = new Tile(new Sprite(1,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_1 = new Tile(new Sprite(2,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_1 = new Tile(new Sprite(3,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_1 = new Tile(new Sprite(4,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_1 = new Tile(new Sprite(5,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_1 = new Tile(new Sprite(6,1,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_1 = new Tile(new Sprite(7,1,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_2 = new Tile(new Sprite(0,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_2 = new Tile(new Sprite(1,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_2 = new Tile(new Sprite(2,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_2 = new Tile(new Sprite(3,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_2 = new Tile(new Sprite(4,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_2 = new Tile(new Sprite(5,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_2 = new Tile(new Sprite(6,2,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_2 = new Tile(new Sprite(7,2,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_3 = new Tile(new Sprite(0,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_3 = new Tile(new Sprite(1,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_3 = new Tile(new Sprite(2,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_3 = new Tile(new Sprite(3,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_3 = new Tile(new Sprite(4,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_3 = new Tile(new Sprite(5,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_3 = new Tile(new Sprite(6,3,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_3 = new Tile(new Sprite(7,3,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_4 = new Tile(new Sprite(0,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_4 = new Tile(new Sprite(1,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_4 = new Tile(new Sprite(2,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_4 = new Tile(new Sprite(3,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_4 = new Tile(new Sprite(4,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_4 = new Tile(new Sprite(5,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_4 = new Tile(new Sprite(6,4,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_4 = new Tile(new Sprite(7,4,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_5 = new Tile(new Sprite(0,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_5 = new Tile(new Sprite(1,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_5 = new Tile(new Sprite(2,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_5 = new Tile(new Sprite(3,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_5 = new Tile(new Sprite(4,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_5 = new Tile(new Sprite(5,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_5 = new Tile(new Sprite(6,5,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_5 = new Tile(new Sprite(7,5,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_6 = new Tile(new Sprite(0,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_6 = new Tile(new Sprite(1,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_6 = new Tile(new Sprite(2,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_6 = new Tile(new Sprite(3,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_6 = new Tile(new Sprite(4,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_6 = new Tile(new Sprite(5,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_6 = new Tile(new Sprite(6,6,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_6 = new Tile(new Sprite(7,6,SpriteSheet.walltile1),true);

	public final static Tile wt1_0_7 = new Tile(new Sprite(0,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_1_7 = new Tile(new Sprite(1,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_2_7 = new Tile(new Sprite(2,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_3_7 = new Tile(new Sprite(3,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_4_7 = new Tile(new Sprite(4,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_5_7 = new Tile(new Sprite(5,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_6_7 = new Tile(new Sprite(6,7,SpriteSheet.walltile1),true);
	public final static Tile wt1_7_7 = new Tile(new Sprite(7,7,SpriteSheet.walltile1),true);

	public final static Tile wt2_0_0 = new Tile(new Sprite(0,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_0 = new Tile(new Sprite(1,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_0 = new Tile(new Sprite(2,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_0 = new Tile(new Sprite(3,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_0 = new Tile(new Sprite(4,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_0 = new Tile(new Sprite(5,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_0 = new Tile(new Sprite(6,0,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_0 = new Tile(new Sprite(7,0,SpriteSheet.walltile2),true);
	
	public final static Tile wt2_0_1 = new Tile(new Sprite(0,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_1 = new Tile(new Sprite(1,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_1 = new Tile(new Sprite(2,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_1 = new Tile(new Sprite(3,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_1 = new Tile(new Sprite(4,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_1 = new Tile(new Sprite(5,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_1 = new Tile(new Sprite(6,1,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_1 = new Tile(new Sprite(7,1,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_2 = new Tile(new Sprite(0,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_2 = new Tile(new Sprite(1,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_2 = new Tile(new Sprite(2,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_2 = new Tile(new Sprite(3,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_2 = new Tile(new Sprite(4,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_2 = new Tile(new Sprite(5,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_2 = new Tile(new Sprite(6,2,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_2 = new Tile(new Sprite(7,2,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_3 = new Tile(new Sprite(0,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_3 = new Tile(new Sprite(1,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_3 = new Tile(new Sprite(2,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_3 = new Tile(new Sprite(3,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_3 = new Tile(new Sprite(4,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_3 = new Tile(new Sprite(5,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_3 = new Tile(new Sprite(6,3,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_3 = new Tile(new Sprite(7,3,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_4 = new Tile(new Sprite(0,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_4 = new Tile(new Sprite(1,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_4 = new Tile(new Sprite(2,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_4 = new Tile(new Sprite(3,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_4 = new Tile(new Sprite(4,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_4 = new Tile(new Sprite(5,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_4 = new Tile(new Sprite(6,4,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_4 = new Tile(new Sprite(7,4,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_5 = new Tile(new Sprite(0,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_5 = new Tile(new Sprite(1,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_5 = new Tile(new Sprite(2,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_5 = new Tile(new Sprite(3,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_5 = new Tile(new Sprite(4,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_5 = new Tile(new Sprite(5,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_5 = new Tile(new Sprite(6,5,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_5 = new Tile(new Sprite(7,5,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_6 = new Tile(new Sprite(0,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_6 = new Tile(new Sprite(1,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_6 = new Tile(new Sprite(2,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_6 = new Tile(new Sprite(3,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_6 = new Tile(new Sprite(4,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_6 = new Tile(new Sprite(5,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_6 = new Tile(new Sprite(6,6,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_6 = new Tile(new Sprite(7,6,SpriteSheet.walltile2),true);

	public final static Tile wt2_0_7 = new Tile(new Sprite(0,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_1_7 = new Tile(new Sprite(1,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_2_7 = new Tile(new Sprite(2,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_3_7 = new Tile(new Sprite(3,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_4_7 = new Tile(new Sprite(4,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_5_7 = new Tile(new Sprite(5,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_6_7 = new Tile(new Sprite(6,7,SpriteSheet.walltile2),true);
	public final static Tile wt2_7_7 = new Tile(new Sprite(7,7,SpriteSheet.walltile2),true);
	
	public final static Tile wt3_0_0 = new Tile(new Sprite(0,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_0 = new Tile(new Sprite(1,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_0 = new Tile(new Sprite(2,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_0 = new Tile(new Sprite(3,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_0 = new Tile(new Sprite(4,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_0 = new Tile(new Sprite(5,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_0 = new Tile(new Sprite(6,0,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_0 = new Tile(new Sprite(7,0,SpriteSheet.walltile3),true);
	
	public final static Tile wt3_0_1 = new Tile(new Sprite(0,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_1 = new Tile(new Sprite(1,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_1 = new Tile(new Sprite(2,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_1 = new Tile(new Sprite(3,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_1 = new Tile(new Sprite(4,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_1 = new Tile(new Sprite(5,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_1 = new Tile(new Sprite(6,1,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_1 = new Tile(new Sprite(7,1,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_2 = new Tile(new Sprite(0,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_2 = new Tile(new Sprite(1,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_2 = new Tile(new Sprite(2,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_2 = new Tile(new Sprite(3,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_2 = new Tile(new Sprite(4,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_2 = new Tile(new Sprite(5,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_2 = new Tile(new Sprite(6,2,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_2 = new Tile(new Sprite(7,2,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_3 = new Tile(new Sprite(0,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_3 = new Tile(new Sprite(1,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_3 = new Tile(new Sprite(2,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_3 = new Tile(new Sprite(3,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_3 = new Tile(new Sprite(4,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_3 = new Tile(new Sprite(5,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_3 = new Tile(new Sprite(6,3,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_3 = new Tile(new Sprite(7,3,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_4 = new Tile(new Sprite(0,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_4 = new Tile(new Sprite(1,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_4 = new Tile(new Sprite(2,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_4 = new Tile(new Sprite(3,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_4 = new Tile(new Sprite(4,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_4 = new Tile(new Sprite(5,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_4 = new Tile(new Sprite(6,4,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_4 = new Tile(new Sprite(7,4,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_5 = new Tile(new Sprite(0,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_5 = new Tile(new Sprite(1,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_5 = new Tile(new Sprite(2,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_5 = new Tile(new Sprite(3,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_5 = new Tile(new Sprite(4,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_5 = new Tile(new Sprite(5,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_5 = new Tile(new Sprite(6,5,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_5 = new Tile(new Sprite(7,5,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_6 = new Tile(new Sprite(0,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_6 = new Tile(new Sprite(1,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_6 = new Tile(new Sprite(2,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_6 = new Tile(new Sprite(3,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_6 = new Tile(new Sprite(4,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_6 = new Tile(new Sprite(5,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_6 = new Tile(new Sprite(6,6,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_6 = new Tile(new Sprite(7,6,SpriteSheet.walltile3),true);

	public final static Tile wt3_0_7 = new Tile(new Sprite(0,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_1_7 = new Tile(new Sprite(1,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_2_7 = new Tile(new Sprite(2,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_3_7 = new Tile(new Sprite(3,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_4_7 = new Tile(new Sprite(4,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_5_7 = new Tile(new Sprite(5,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_6_7 = new Tile(new Sprite(6,7,SpriteSheet.walltile3),true);
	public final static Tile wt3_7_7 = new Tile(new Sprite(7,7,SpriteSheet.walltile3),true);

	
	public final static Tile txt2_0_0 = new Tile(new Sprite(0,0,SpriteSheet.texture2),false);
	public final static Tile txt2_1_0 = new Tile(new Sprite(1,0,SpriteSheet.texture2),false);
	public final static Tile txt2_2_0 = new Tile(new Sprite(2,0,SpriteSheet.texture2),false);
	public final static Tile txt2_3_0 = new Tile(new Sprite(3,0,SpriteSheet.texture2),false);

	public final static Tile txt2_0_1 = new Tile(new Sprite(0,1,SpriteSheet.texture2),false);
	public final static Tile txt2_1_1 = new Tile(new Sprite(1,1,SpriteSheet.texture2),false);
	public final static Tile txt2_2_1 = new Tile(new Sprite(2,1,SpriteSheet.texture2),false);
	public final static Tile txt2_3_1 = new Tile(new Sprite(3,1,SpriteSheet.texture2),false);

	public final static Tile txt2_0_2 = new Tile(new Sprite(0,2,SpriteSheet.texture2),false);
	public final static Tile txt2_1_2 = new Tile(new Sprite(1,2,SpriteSheet.texture2),false);
	public final static Tile txt2_2_2 = new Tile(new Sprite(2,2,SpriteSheet.texture2),false);
	public final static Tile txt2_3_2 = new Tile(new Sprite(3,2,SpriteSheet.texture2),false);

	public final static Tile txt2_0_3 = new Tile(new Sprite(0,3,SpriteSheet.texture2),false);
	public final static Tile txt2_1_3 = new Tile(new Sprite(1,3,SpriteSheet.texture2),false);
	public final static Tile txt2_2_3 = new Tile(new Sprite(2,3,SpriteSheet.texture2),false);
	public final static Tile txt2_3_3 = new Tile(new Sprite(3,3,SpriteSheet.texture2),false);

	public final static Tile txt2_0_4 = new Tile(new Sprite(0,4,SpriteSheet.texture2),true);
	public final static Tile txt2_1_4 = new Tile(new Sprite(1,4,SpriteSheet.texture2),true);
	public final static Tile txt2_2_4 = new Tile(new Sprite(2,4,SpriteSheet.texture2),true);
	public final static Tile txt2_3_4 = new Tile(new Sprite(3,4,SpriteSheet.texture2),true);

	public final static Tile txt2_0_5 = new Tile(new Sprite(0,5,SpriteSheet.texture2),true);
	public final static Tile txt2_1_5 = new Tile(new Sprite(1,5,SpriteSheet.texture2),true);
	public final static Tile txt2_2_5 = new Tile(new Sprite(2,5,SpriteSheet.texture2),true);
	public final static Tile txt2_3_5 = new Tile(new Sprite(3,5,SpriteSheet.texture2),true);
	
	
	private boolean solid;
	private Sprite sprite;
	public final int size = 16;
	
	public Tile(Sprite sprite, boolean solid) {
		this.sprite=sprite;
		this.solid=solid;
	}

	public Tile(int color) {
		this.sprite=new Sprite(16,16,color);
		solid=false;
	}
	
	public Sprite getSprite() {
		return sprite;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderTile(x,y,this);
	}
	
	public boolean isSolid() {
		return this.solid;
	}
}
