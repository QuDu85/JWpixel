package game.com.level.spritesheet;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class SpriteSheet {
	public final static SpriteSheet floortile1 = new SpriteSheet("res/tilesheet/floortile1.png");
	public final static SpriteSheet floortile2 = new SpriteSheet("res/tilesheet/floortile2.png");
	public final static SpriteSheet walltile1 = new SpriteSheet("res/tilesheet/walltile1.png");
	public final static SpriteSheet walltile2 = new SpriteSheet("res/tilesheet/walltile2.png");
	public final static SpriteSheet walltile3 = new SpriteSheet("res/tilesheet/walltile3.png");
	public final static SpriteSheet texture2 = new SpriteSheet("res/tilesheet/map2.png");
	public final static SpriteSheet playersheet = new SpriteSheet("res/playersheet/john.png");
	public final static SpriteSheet ranged = new SpriteSheet("res/minionsheet/ranged.png");
	public final static SpriteSheet hunter = new SpriteSheet("res/minionsheet/balanced.png");
	public final static SpriteSheet tank = new SpriteSheet("res/minionsheet/tank.png");
	public final static SpriteSheet boss = new SpriteSheet("res/minionsheet/boss.png");
	public final static SpriteSheet bossstagger = new SpriteSheet("res/minionsheet/bossstagger.png");
	public final static SpriteSheet projectile = new SpriteSheet("res/projectile/kunai.png");
	public final static SpriteSheet rangedprojectile = new SpriteSheet("res/projectile/rangedbullet.png");
	public final static SpriteSheet balancedprojectile = new SpriteSheet("res/projectile/balancedbullet.png");
	public final static SpriteSheet playershoot = new SpriteSheet("res/attacksheet/johnshoot.png");
	public final static SpriteSheet playerpunch = new SpriteSheet("res/attacksheet/johnpunch.png");
	public final static SpriteSheet huntershoot = new SpriteSheet("res/attacksheet/huntershoot.png");
	public final static SpriteSheet hunterpunch = new SpriteSheet("res/attacksheet/hunterpunch.png");
	public final static SpriteSheet tankattack = new SpriteSheet("res/attacksheet/tankattack.png");
	public final static SpriteSheet rangedattack = new SpriteSheet("res/attacksheet/rangedattack.png");
	public final static SpriteSheet bossattack = new SpriteSheet("res/attacksheet/bossattack.png");
	public final static SpriteSheet trap = new SpriteSheet("res/static/trap.png");
	public final static SpriteSheet bubble = new SpriteSheet("res/static/bubble.png");
	public final static SpriteSheet dog = new SpriteSheet("res/static/dog.png");
	public final static SpriteSheet missile = new SpriteSheet("res/projectile/missile.png");

	private int width, height;
	public int[] pixels;

	public SpriteSheet(String path) {
		load(path);
	}

	public SpriteSheet(int x, int y, int width, int height, SpriteSheet sheet) {
		pixels = new int[width * height];
		this.width = width;
		this.height = height;
		for (int h = 0; h < height; h++) {
			for (int w = 0; w < width; w++)
				pixels[w + h * width] = sheet.pixels[(x + w) + (y + h) * sheet.getWidth()];
		}
	}

	public void load(String path) {
		try {
			BufferedImage image = ImageIO.read(new File(path));
			width = image.getWidth();
			height = image.getHeight();
			pixels = new int[width * height];
			image.getRGB(0, 0, width, height, pixels, 0, width);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

}
