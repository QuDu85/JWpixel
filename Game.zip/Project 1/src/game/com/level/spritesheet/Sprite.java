package game.com.level.spritesheet;

public class Sprite {
	private int width, height;
	public int pixels[];
	private int x, y;
	public static final Sprite bulletup = new Sprite(16, 16, 16, 16, SpriteSheet.projectile);
	public static final Sprite bulletforward = new Sprite(16, 0, 16, 16, SpriteSheet.projectile);

	public Sprite(int x, int y, int width, int height, SpriteSheet sheet) {
		this.width = width;
		this.height = height;
		this.x = x;
		this.y = y;
		pixels = new int[width * height];
		load(sheet);
	}

	public Sprite(int x, int y, SpriteSheet sheet) {
		this.x = x << 4;
		this.y = y << 4;
		this.width = 16;
		this.height = 16;
		pixels = new int[width * height];
		load(sheet);
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Sprite(int width, int height, int color) {
		this.width = width;
		this.height = height;
		pixels = new int[width * height];
		for (int i = 0; i < pixels.length; i++)
			pixels[i] = color;
	}

	private void load(SpriteSheet sheet) {
		for (int h = 0; h < height; h++)
			for (int w = 0; w < width; w++) {
				pixels[w + h * width] = sheet.pixels[(x + w) + (y + h) * sheet.getWidth()];
			}
	}

}
