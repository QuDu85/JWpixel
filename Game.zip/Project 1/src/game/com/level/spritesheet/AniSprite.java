package game.com.level.spritesheet;

import game.com.level.entity.mob.bot.Minion.PATTERN;

public class AniSprite {
	private Sprite sprites[];
	private int width, height;
	private int frame=0;
	private int length;
	private int time=0;
	private double fps=3;
	private PATTERN pattern;
	
	public AniSprite(int width, int height, SpriteSheet sheet, PATTERN pattern) {
		this.width=width;
		this.height=height;
		if(pattern==PATTERN.VERTICAL)
		length=sheet.getHeight()/height;
		else length=sheet.getWidth()/width;
		sprites = new Sprite [length];
		this.pattern=pattern;
		loadSprite(sheet);
	}
	
	public void loadSprite(SpriteSheet sheet) {
		if(pattern==PATTERN.VERTICAL)
			for(int i=0; i<length;i++) 
				sprites [i] = new Sprite(0,i*height, width, height, sheet);	
		else
			for(int i=0; i<length;i++) 
				sprites [i] = new Sprite(i*width,0, width, height, sheet);
	}
	
	public void update() {
		time++;
		if(time>60/fps) {
			frame=(frame+1)%length;
			time=0;
		}
	}
	
	public void setFPS(double fps) {
		this.fps=fps;
	}
	
	public Sprite[] getSprites() {
		return sprites;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public int getFrame() {
		return frame;
	}

	public int getLength() {
		return length;
	}

	public int getTime() {
		return time;
	}

	public double getFps() {
		return fps;
	}
	
	public Sprite getFrame(int i) {
		return sprites[i];
	}

	public Sprite frame() {
		return sprites[frame];
	}
	
	public void setFrame(int frame) {
		this.frame=frame;
	}
}
