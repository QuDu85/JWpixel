package game.com.level;

import java.util.Random;

import game.com.level.entity.Entity;
import game.com.screen.Screen;

public class Particle extends Entity{
	protected double x0,y0,z0;
	protected double speed=2;
	protected int color;
	
	private Random random = new Random();
	public enum EFFECT{
		RANDOM, FALLING, DEFLECT, EVAPORATE
	}
	protected EFFECT effect;
	protected double time;
	protected double time0;
	
	public Particle() {
		
	}
	
	public Particle(double x, double y,int color, int size,EFFECT effect, double time) {
		this.x=x;
		this.y=y;
		this.color=color;
		this.width=size;
		this.height=size;
		this.time= time + random.nextGaussian()*(time/5);
		time0 = time;
		this.effect=effect;
		initEffect(effect);
		
	}
	
	private void initEffect(EFFECT effect) {
		if(effect==EFFECT.RANDOM) {
			x0=random.nextGaussian()*speed;
			y0=random.nextGaussian()*speed;
		}else if(effect==EFFECT.FALLING) {
			x0=random.nextGaussian()*speed;
			y0=-Math.abs(random.nextGaussian()*speed);
		}else if(effect==EFFECT.EVAPORATE) {
			x0=random.nextGaussian()*speed;
			y0=-Math.abs(random.nextGaussian()*speed);
			z=15;
			z0 = -Math.abs(random.nextGaussian()*speed);
		}
	}
	
	public void move() {
		if(collision(x,y,x0,y0,width,height)) {
			x0 = -x0;
			y0 =- y0;
		}
		x+=x0;
		y+=y0;
	}
	
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getX0() {
		return x0;
	}

	public double getY0() {
		return y0;
	}

	public double getSpeed() {
		return speed;
	}

	public int getSize() {
		return width;
	}

	public int getColor() {
		return color;
	}

	public double getTime() {
		return time;
	}

	public Random getRandom() {
		return random;
	}

	public void falling() {
		x0 -=4 * sign(x0)/(time);
		if(Math.abs(x0) < 0.1) x0 = 0;
		y0+= 0.2;
		if(time < time0 / 2) y0 = 0;
		
	} 
	
	public double sign(double x) {
		if(x>0) return 1;
		else if(x<0) return -1;
		return 0;
	}

	public boolean collision(double x, double y, double x0, double y0, int width, int height) {
		int xt;
		int yt= ((int) (y +y0 +height/2)) >>4;
		for(int i=0;i<2;i++) {
			xt=((int)(x+x0-width/2+i*width))>>4;
			if(level.getTile(xt, yt).isSolid()) return true;
		}
		return false;
	}
	
	public void bouncing() {
		x0 -=4 * sign(x0)/(time);
		if(Math.abs(x0) < 0.1) x0 = 0;
		z+=z0;
		if(z <= 0) {
			z0 = -z0 / 2;
		}
		z0 -= 4 * sign(z0)/(time);
	}
	
	public void update() {
		time--;
		if(effect == EFFECT.FALLING) {
			
			falling();
		}
		if(effect==EFFECT.EVAPORATE)
			bouncing();
			
		if(time<0)
			level.remove(this);
		move();
	}
	
	public void render(Screen screen) {
		screen.renderParticle((int)x-width/2,(int)y-height/2,this);
	}
}
