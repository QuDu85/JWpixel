package game.com;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;

import game.com.UI.UIButton;
import game.com.UI.UIButtonAction;
import game.com.UI.UICheckBox;
import game.com.UI.UIImage;
import game.com.UI.UIManager;
import game.com.UI.UIPanel;
import game.com.input.keyboard.Keyboard;
import game.com.input.mouse.Mouse;
import game.com.level.entity.mob.bot.EliteBot;
import game.com.level.entity.mob.bot.Minion;
import game.com.levelsys.LevelSys;
import game.com.levelsys.LevelSys.MODE;
import game.com.screen.Screen;

public class Game extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;
	public final static int width = 300;
	public final static int height = width * 9 / 16;
	public final static int scale = 4;
	private Thread thread;
	private boolean running = false;
	private JFrame frame;
	private BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	private int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	private LevelSys levelsys;
	private Screen screen;
	private Keyboard key;
	private Minion[] panda;
	private EliteBot elite;
	private MODE gameMode;
	private Mouse mouse;
	private int delayTime;
	private boolean pause;

	private static boolean ingame;

	// UI
	private static UIManager ui = new UIManager();
	private UIPanel home;
	private UIImage logo;
	private UIButton startgame;
	private UIButton difficulty;
	private UIButton exit;
	private UIPanel gameover;
	private UIImage overImage;
	private UIButton overExit;
	private UIButton restart;
	private UIButton overHome;

	private UIPanel mode;
	private UIImage modeImage;
	private UICheckBox easy;
	private UICheckBox hard;
	private UIButton back;

	private UIPanel pauseMenu;
	private UIImage pauseImage;
	private UIButton pauseExit;
	private UIButton pauseBack;

	private UIPanel victory;
	private UIImage vImage;
	private UIButton vHome;
	private UIButton vExit;
	private static boolean isVictory = false;

	public Game() {
		Dimension size = new Dimension(width * scale, height * scale);
		setPreferredSize(size);
		frame = new JFrame();
		screen = new Screen(width, height);
		key = new Keyboard();
		mouse = new Mouse();
		gameMode = MODE.EASY;
		delayTime = 0;
		pause = false;
		ingame = false;

		addKeyListener(key);
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
		loadUI();
	}

	public void loadUI() {
		// Home
		home = new UIPanel("home", 0, 0, Game.width, Game.height, new Color(0xdd444344, true));
		ui.setCur(home);
		ui.add(home);

		logo = new UIImage(0, 0, "res/ui/logo.png");
		home.add(logo);

		startgame = new UIButton(130, 109, 35, 12, new Color(0xaad4ae3a, true), new UIButtonAction() {

			public void perform() {
				ingame = true;
				loadGame(gameMode);
				ui.changePanel("playerUI");
				ui.setTempVisible(false);
			}

		});

		startgame.setMouse(mouse);
		startgame.setText(2, 9, "Start Game", "Futura");
		home.add(startgame);

		difficulty = new UIButton(130, 129, 35, 12, new Color(0xaace743d, true), new UIButtonAction() {
			public void perform() {
				ui.changePanel("mode");
				ui.setTempVisible(false);
			}

		});

		difficulty.setMouse(mouse);
		difficulty.setText(9, 9, "Mode", "Futura");
		home.add(difficulty);

		exit = new UIButton(130, 149, 35, 12, new Color(0xaaa0a0ae, true), new UIButtonAction() {

			public void perform() {
				System.exit(0);
			}

		});

		exit.setMouse(mouse);
		exit.setText(12, 9, "Exit", "Futura");
		home.add(exit);

		// Change difficulty
		mode = new UIPanel("mode", 0, 0, Game.width, Game.height, new Color(0xaa1f1f1f, true));
		ui.add(mode);

		UIButtonAction pressAction1 = new UIButtonAction() {
			public void perform() {
				gameMode = MODE.EASY;
				hard.setStat(false);
			}

		};

		UIButtonAction releaseAction1 = new UIButtonAction() {
			public void perform() {
				gameMode = MODE.HARD;
				easy.setStat(false);
			}

		};

		modeImage = new UIImage(0, 0, "res/ui/mode.png");
		mode.add(modeImage);

		easy = new UICheckBox(130, 109, 35, 12, new Color(0xaa355492, true), true, pressAction1, releaseAction1);
		easy.setMouse(mouse);
		easy.setText(11, 9, "Easy", "Futura");
		mode.add(easy);

		UIButtonAction pressAction2 = new UIButtonAction() {
			public void perform() {
				gameMode = MODE.HARD;
				easy.setStat(false);
			}

		};

		UIButtonAction releaseAction2 = new UIButtonAction() {
			public void perform() {
				gameMode = MODE.EASY;
				hard.setStat(false);
			}

		};

		hard = new UICheckBox(130, 128, 35, 12, new Color(0xaab73251, true), false, pressAction2, releaseAction2);
		hard.setMouse(mouse);
		hard.setText(11, 9, "Hard", "Futura");
		mode.add(hard);

		back = new UIButton(130, 149, 35, 12, new Color(0xaa85816d, true), new UIButtonAction() {
			public void perform() {
				ui.changePanel("home");
			}

		});
		back.setMouse(mouse);
		back.setText(11, 9, "Back", "Futura");
		mode.add(back);

		// Pause
		pauseMenu = new UIPanel("pause", 0, 0, Game.width, Game.height, new Color(0x001f1f1f, true));
		ui.add(pauseMenu);
		pauseImage = new UIImage(0, 0, "res/ui/pause.png");
		pauseMenu.add(pauseImage);

		pauseBack = new UIButton(130, 128, 35, 12, new Color(0xdd85816d, true), new UIButtonAction() {
			public void perform() {
				pause = false;
				ui.changePanel("playerUI");
			}
		});
		pauseBack.setMouse(mouse);
		pauseBack.setText(7, 9, "Resume", "Futura");
		pauseMenu.add(pauseBack);

		pauseExit = new UIButton(130, 149, 35, 12, new Color(0xaaa0a0ae, true), new UIButtonAction() {
			public void perform() {
				System.exit(0);
			}
		});

		pauseExit.setMouse(mouse);
		pauseExit.setText(12, 9, "Exit", "Futura");
		pauseMenu.add(pauseExit);

		// Gameover
		gameover = new UIPanel("gameover", 0, 0, Game.width, Game.height, new Color(0x001f1f1f, true));
		ui.add(gameover);
		overImage = new UIImage(0, 0, "res/ui/gameover.png");

		gameover.add(overImage);
		restart = new UIButton(130, 109, 35, 12, new Color(0xaae23f3f, true), new UIButtonAction() {

			public void perform() {
				levelsys.restart();
			}

		});

		restart.setMouse(mouse);
		restart.setText(7, 9, "Restart", "Futura");
		gameover.add(restart);

		overHome = new UIButton(130, 128, 35, 12, new Color(0xaabab147, true), new UIButtonAction() {

			public void perform() {
				ingame = false;
				ui.changePanel("home");
				ui.setTempVisible(false);
			}
		});
		overHome.setMouse(mouse);
		overHome.setText(9, 9, "Home", "Futura");
		gameover.add(overHome);

		overExit = new UIButton(130, 149, 35, 12, new Color(0xaaa0a0ae, true), new UIButtonAction() {
			public void perform() {
				System.exit(0);
			}
		});

		overExit.setMouse(mouse);
		overExit.setText(12, 9, "Exit", "Futura");
		gameover.add(overExit);

		// Victory
		victory = new UIPanel("victory", 0, 0, Game.width, Game.height, new Color(0xdd1f1f1f, true));
		ui.add(victory);

		vImage = new UIImage(0, 0, "res/ui/victory.png");
		victory.add(vImage);

		vHome = new UIButton(130, 128, 35, 12, new Color(0xaabab147, true), new UIButtonAction() {
			public void perform() {
				ingame = false;
				isVictory = false;
				ui.changePanel("home");
				ui.setTempVisible(false);
			}
		});

		vHome.setMouse(mouse);
		vHome.setText(9, 9, "Home", "Futura");
		victory.add(vHome);

		vExit = new UIButton(130, 149, 35, 12, new Color(0xaaa0a0ae, true), new UIButtonAction() {
			public void perform() {
				System.exit(0);
			}
		});

		vExit.setMouse(mouse);
		vExit.setText(12, 9, "Exit", "Futura");
		victory.add(vExit);
	}

	public static UIManager getUI() {
		return ui;
	}

	public void loadGame(MODE mode) {
		levelsys = new LevelSys(mouse, key, mode);
		levelsys.getPlayer().setScreen(screen);
	}

	public synchronized void start() {
		running = true;
		thread = new Thread(this);
		thread.start();
	}

	public synchronized void stop() {
		running = false;

		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void update() {
		key.update();
		if (key.pause && delayTime < 0) {
			if (pause == true)
				pause = false;
			else
				pause = true;
			delayTime = 30;
		}

		sysControl();
		ui.update();
		
		delayTime--;
		if (delayTime < -1000)
			delayTime = -1;

	}

	public void sysControl() {
		if(isVictory) {
			ui.changePanel("victory");
			ui.setTempVisible(false);
		}
		if (ingame) {
			if (pause) {
				ui.changePanel("pause");
				ui.setTempVisible(false);
			} else {
				levelsys.getCurLevel().update();
			}
			if (!pause) {
				if (!levelsys.isGameover())
					ui.changePanel("playerUI");
			}
		}
	}

	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if (bs == null) {
			createBufferStrategy(3);
			return;
		}

		Graphics g = bs.getDrawGraphics();
		if (ingame) {

			screen.clear();
			screenControl();
			for (int i = 0; i < pixels.length; i++) {
				pixels[i] = screen.pixels[i];
			}
			g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		}

		ui.render(g);
		g.dispose();
		bs.show();
	}

	public static void setIngame(boolean ingame) {
		Game.ingame = ingame;
	}

	public static void setVictory(boolean victory) {
		Game.isVictory = victory;
		
	}
	public void screenControl() {
		int xBorder = levelsys.getCurLevel().getWidth();
		int yBorder = levelsys.getCurLevel().getHeight();
		int xOffset = (int) levelsys.getPlayer().getX() - width / 2;
		int yOffset = (int) levelsys.getPlayer().getY() - height / 2;
		if (xOffset < 0)
			xOffset = 0;
		if (yOffset < 0)
			yOffset = 0;
		if (xBorder - xOffset < screen.getWidth())
			xOffset = xBorder - screen.getWidth();
		if (yBorder - yOffset < screen.getHeight())
			yOffset = yBorder - screen.getHeight();
		screen.setOffset(xOffset, yOffset);
		levelsys.getCurLevel().render(screen);
	}

	@Override
	public void run() {
		requestFocus();
		long lastTime = System.nanoTime();
		double nanoTime = 1e9 / 60;
		double delta = 0;
		long time = System.currentTimeMillis();
		int updates = 0;
		int frames = 0;
		while (running) {
			long currentTime = System.nanoTime();
			delta += (currentTime - lastTime) / nanoTime;
			lastTime = currentTime;
			while (delta >= 1) {
				update();
				updates++;
				delta--;
			}
			frames++;
			render();
			if (System.currentTimeMillis() - time > 1000) {
				time += 1000;
				frame.setTitle("ups:" + updates + "/ fps:" + frames);
				updates = 0;
				frames = 0;
			}
		}
	}

	public static void main(String[] args) {
		Game game = new Game();
		game.frame.add(game);
		game.frame.pack();
		game.frame.setResizable(false);
		game.frame.setLocationRelativeTo(null);
		game.frame.setVisible(true);
		game.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		game.start();

	}

}
